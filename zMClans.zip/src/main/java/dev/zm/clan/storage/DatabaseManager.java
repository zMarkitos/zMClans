package dev.zm.clan.storage;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import dev.zm.clan.config.ConfigManager;
import dev.zm.clan.zMClans;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;

/**
 * Manages the HikariCP connection pool for SQLite or MySQL.
 * All SQL is executed through {@link #getConnection()}.
 */
public final class DatabaseManager {

    private final zMClans plugin;
    private HikariDataSource dataSource;

    // Schema version — bump when adding migrations
    private static final int CURRENT_SCHEMA_VERSION = 1;

    public DatabaseManager(zMClans plugin) {
        this.plugin = plugin;
    }

    /** Establishes the connection pool. @return {@code true} if successful. */
    public boolean connect() {
        ConfigManager cfg = plugin.getConfigManager();
        HikariConfig hc = new HikariConfig();

        if ("MYSQL".equalsIgnoreCase(cfg.getStorageType())) {
            hc.setDriverClassName("com.mysql.cj.jdbc.Driver");
            hc.setJdbcUrl(String.format("jdbc:mysql://%s:%d/%s?useSSL=%b&allowPublicKeyRetrieval=true&characterEncoding=utf8",
                    cfg.getMysqlHost(), cfg.getMysqlPort(), cfg.getMysqlDatabase(), cfg.isMysqlSsl()));
            hc.setUsername(cfg.getMysqlUser());
            hc.setPassword(cfg.getMysqlPassword());
            hc.setMaximumPoolSize(cfg.getMysqlPoolSize());
        } else {
            // SQLite
            File dbFile = new File(plugin.getDataFolder(), cfg.getSqliteFile());
            dbFile.getParentFile().mkdirs();
            hc.setDriverClassName("org.sqlite.JDBC");
            hc.setJdbcUrl("jdbc:sqlite:" + dbFile.getAbsolutePath());
            hc.setMaximumPoolSize(1); // SQLite is single-writer
            // Keep connection alive
            hc.setConnectionTestQuery("SELECT 1");
        }

        hc.setPoolName("zMClans-Pool");
        hc.addDataSourceProperty("cachePrepStmts", "true");
        hc.addDataSourceProperty("prepStmtCacheSize", "250");
        hc.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");

        try {
            dataSource = new HikariDataSource(hc);
            plugin.getLogger().info(plugin.getMessages().get("db-connected",
                    "type", cfg.getStorageType()));
            return true;
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE,
                    plugin.getMessages().get("db-error", "error", e.getMessage()), e);
            return false;
        }
    }

    /** Runs all pending schema migrations in order. */
    public void runMigrations() {
        try (Connection con = getConnection(); Statement stmt = con.createStatement()) {

            // Migration v1 — initial schema
            plugin.getLogger().info(plugin.getMessages().get("db-migration", "version", "1"));

            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS clans (
                    id            TEXT PRIMARY KEY,
                    name          TEXT NOT NULL UNIQUE,
                    tag           TEXT NOT NULL UNIQUE,
                    description   TEXT DEFAULT '',
                    leader        TEXT NOT NULL,
                    leader_rank   TEXT NOT NULL DEFAULT 'leader',
                    friendly_fire INTEGER NOT NULL DEFAULT 0,
                    open_invite   INTEGER NOT NULL DEFAULT 0,
                    home          TEXT DEFAULT NULL,
                    points        INTEGER NOT NULL DEFAULT 0,
                    created_at    INTEGER NOT NULL
                )
            """);

            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS clan_members (
                    player_uuid TEXT NOT NULL,
                    clan_id     TEXT NOT NULL,
                    rank_id     TEXT NOT NULL DEFAULT 'member',
                    joined_at   INTEGER NOT NULL,
                    PRIMARY KEY (player_uuid),
                    FOREIGN KEY (clan_id) REFERENCES clans(id) ON DELETE CASCADE
                )
            """);

            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS schema_version (
                    version INTEGER NOT NULL
                )
            """);

            // Ensure version row exists
            var rs = stmt.executeQuery("SELECT COUNT(*) FROM schema_version");
            if (rs.next() && rs.getInt(1) == 0) {
                stmt.executeUpdate("INSERT INTO schema_version VALUES (" + CURRENT_SCHEMA_VERSION + ")");
            }

        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Migration failed!", e);
        }
    }

    /** Returns a connection from the pool. Callers must close it in a try-with-resources. */
    public Connection getConnection() throws SQLException {
        if (dataSource == null || dataSource.isClosed()) {
            throw new SQLException("DataSource is not available.");
        }
        return dataSource.getConnection();
    }

    /** Gracefully shuts down the connection pool. */
    public void shutdown() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }
}
