package dev.zm.clan.command;

import dev.zm.clan.clan.model.Clan;
import dev.zm.clan.config.ColorUtil;
import dev.zm.clan.invitation.model.Invitation;
import dev.zm.clan.member.model.ClanMember;
import dev.zm.clan.rank.model.ClanRank;
import dev.zm.clan.service.ClanService;
import dev.zm.clan.service.HomeService;
import dev.zm.clan.service.InviteService;
import dev.zm.clan.service.MemberService;
import dev.zm.clan.zMClans;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Main command executor and tab completer for /clan.
 */
public final class ClanCommand implements CommandExecutor, TabCompleter {

    private final zMClans plugin;

    public ClanCommand(zMClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessages().get("player-only"));
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("menu") || args[0].equalsIgnoreCase("gui")) {
            plugin.getMenuManager().openMainMenu(player);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "create" -> handleCreate(player, args);
            case "invite" -> handleInvite(player, args);
            case "invites" -> plugin.getMenuManager().openInvitesMenu(player, 0);
            case "members" -> plugin.getMenuManager().openMembersMenu(player, 0);
            case "settings" -> plugin.getMenuManager().openSettingsMenu(player);
            case "stats" -> plugin.getMenuManager().openStatsMenu(player);
            case "accept" -> handleAccept(player, args);
            case "deny" -> handleDeny(player, args);
            case "kick" -> handleKick(player, args);
            case "leave" -> handleLeave(player);
            case "disband" -> handleDisband(player, args);
            case "info" -> handleInfo(player, args);
            case "list" -> handleList(player, args);
            case "setrank", "rank", "promote" -> handleSetRank(player, args);
            case "sethome" -> handleSetHome(player);
            case "home" -> handleHome(player);
            case "chat", "c" -> handleChat(player, args);
            case "ff", "friendlyfire" -> handleFriendlyFire(player);
            case "desc", "description" -> handleDescription(player, args);
            case "modtag", "tag" -> handleModTag(player, args);
            case "help" -> handleHelp(player);
            default -> player.sendMessage(plugin.getMessages().get("unknown-command"));
        }

        return true;
    }

    private void handleCreate(Player player, String[] args) {
        if (!player.hasPermission("zmclans.clan.create")) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return;
        }
        if (args.length < 2) {
            player.sendMessage(plugin.getMessages().get("usage-create"));
            return;
        }

        String name = args[1];
        String rawTag = args.length >= 3
                ? String.join(" ", Arrays.copyOfRange(args, 2, args.length)).trim()
                : "";

        ClanService.CreateResult result = plugin.getClanService().create(player, name, rawTag);
        switch (result) {
            case OK -> {
                Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());
                String displayTag = optClan.map(Clan::getTag).orElse(rawTag.isEmpty() ? name : rawTag);
                player.sendMessage(plugin.getMessages().get("clan-created", "clan", name, "tag", displayTag));
            }
            case ALREADY_IN_CLAN -> player.sendMessage(plugin.getMessages().get("already-in-clan"));
            case NAME_INVALID -> player.sendMessage(plugin.getMessages().get("clan-name-invalid"));
            case TAG_INVALID -> player.sendMessage(plugin.getMessages().get("clan-tag-invalid"));
            case NAME_TAKEN -> player.sendMessage(plugin.getMessages().get("clan-name-taken", "clan", name));
            case TAG_TAKEN -> {
                String clean = rawTag.isEmpty() ? name : ColorUtil.strip(ColorUtil.colorize(rawTag));
                player.sendMessage(plugin.getMessages().get("clan-tag-taken", "tag", clean));
            }
            case NO_MONEY -> player.sendMessage(plugin.getMessages().get("clan-not-enough-money", "amount", String.valueOf(plugin.getConfigManager().getCreationCost())));
        }
    }

    private void handleInvite(Player player, String[] args) {
        if (!player.hasPermission("zmclans.clan.invite")) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return;
        }
        if (args.length < 2) {
            if (plugin.getClanService().isInClan(player.getUniqueId())) {
                plugin.getMenuManager().openInviteMenu(player, 0);
            } else {
                player.sendMessage(plugin.getMessages().get("usage-invite"));
            }
            return;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null || !target.isOnline()) {
            player.sendMessage(plugin.getMessages().get("player-not-found", "player", args[1]));
            return;
        }

        InviteService.InviteResult result = plugin.getInviteService().sendInvite(player.getUniqueId(), target.getUniqueId());
        switch (result) {
            case OK -> {
                player.sendMessage(plugin.getMessages().get("invite-sent", "player", target.getName()));
                plugin.getClanService().findByPlayer(player.getUniqueId()).ifPresent(clan -> {
                    target.sendMessage(plugin.getMessages().get("invite-received", "clan", clan.getName(), "sender", player.getName()));
                });
            }
            case NO_PERMISSION -> player.sendMessage(plugin.getMessages().get("no-permission-invite"));
            case ALREADY_HAS_CLAN -> player.sendMessage(plugin.getMessages().get("invite-player-has-clan", "player", target.getName()));
            case ALREADY_INVITED -> player.sendMessage(plugin.getMessages().get("invite-already-sent", "player", target.getName()));
            case CLAN_FULL -> {
                Clan c = plugin.getClanService().findByPlayer(player.getUniqueId()).orElse(null);
                String cur = c != null ? String.valueOf(c.getMemberCount()) : "0";
                player.sendMessage(plugin.getMessages().get("invite-clan-full", "amount", cur, "max", String.valueOf(plugin.getConfigManager().getMaxMembers())));
            }
            default -> player.sendMessage(plugin.getMessages().get("player-not-found", "player", args[1]));
        }
    }

    private void handleAccept(Player player, String[] args) {
        List<Invitation> pending = plugin.getInviteService().getPending(player.getUniqueId());
        if (pending.isEmpty()) {
            player.sendMessage(plugin.getMessages().get("no-pending-invites"));
            return;
        }

        UUID targetClanId;
        if (args.length >= 2) {
            Optional<Clan> opt = plugin.getClanService().findByName(args[1]);
            if (opt.isEmpty()) opt = plugin.getClanService().findByTag(args[1]);
            if (opt.isEmpty() || !plugin.getInviteService().hasInviteFrom(player.getUniqueId(), opt.get().getId())) {
                player.sendMessage(plugin.getMessages().get("no-invite-from-clan", "clan", args[1]));
                return;
            }
            targetClanId = opt.get().getId();
        } else {
            targetClanId = pending.get(pending.size() - 1).getClanId();
        }

        if (plugin.getInviteService().accept(player.getUniqueId(), targetClanId)) {
            Clan clan = plugin.getClanService().findById(targetClanId).orElse(null);
            player.sendMessage(plugin.getMessages().get("invite-accepted-receiver", "clan", clan != null ? clan.getName() : ""));
        } else {
            player.sendMessage(plugin.getMessages().get("invite-expired", "clan", ""));
        }
    }

    private void handleDeny(Player player, String[] args) {
        List<Invitation> pending = plugin.getInviteService().getPending(player.getUniqueId());
        if (pending.isEmpty()) {
            player.sendMessage(plugin.getMessages().get("no-pending-invites"));
            return;
        }

        UUID targetClanId;
        if (args.length >= 2) {
            Optional<Clan> opt = plugin.getClanService().findByName(args[1]);
            if (opt.isEmpty()) opt = plugin.getClanService().findByTag(args[1]);
            if (opt.isEmpty()) {
                player.sendMessage(plugin.getMessages().get("no-invite-from-clan", "clan", args[1]));
                return;
            }
            targetClanId = opt.get().getId();
        } else {
            targetClanId = pending.get(pending.size() - 1).getClanId();
        }

        if (plugin.getInviteService().deny(player.getUniqueId(), targetClanId)) {
            Clan clan = plugin.getClanService().findById(targetClanId).orElse(null);
            player.sendMessage(plugin.getMessages().get("invite-denied-receiver", "clan", clan != null ? clan.getName() : ""));
        } else {
            player.sendMessage(plugin.getMessages().get("no-pending-invites"));
        }
    }

    private void handleKick(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(plugin.getMessages().get("usage-kick"));
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        MemberService.KickResult result = plugin.getMemberService().kick(player.getUniqueId(), target.getUniqueId());
        switch (result) {
            case OK -> {
                player.sendMessage(plugin.getMessages().get("member-kicked", "player", args[1]));
                if (target.isOnline() && target.getPlayer() != null) {
                    target.getPlayer().sendMessage(plugin.getMessages().get("kicked-from-clan", "clan", ""));
                }
            }
            case NO_PERMISSION -> player.sendMessage(plugin.getMessages().get("no-permission-kick"));
            case CANNOT_KICK_LEADER -> player.sendMessage(plugin.getMessages().get("cannot-kick-leader"));
            case RANK_TOO_HIGH -> player.sendMessage(plugin.getMessages().get("cannot-kick-higher-rank"));
            case NOT_IN_CLAN -> player.sendMessage(plugin.getMessages().get("not-in-your-clan"));
        }
    }

    private void handleLeave(Player player) {
        Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());
        if (optClan.isEmpty()) {
            player.sendMessage(plugin.getMessages().get("no-clan"));
            return;
        }
        Clan clan = optClan.get();
        if (clan.getLeader().equals(player.getUniqueId())) {
            player.sendMessage(plugin.getMessages().get("leader-cannot-leave"));
            return;
        }

        String title = plugin.getMessages().get("gui-confirm-leave-title");
        plugin.getMenuManager().openConfirm(player, "leave", title, () -> {
            if (plugin.getMemberService().leave(player)) {
                player.sendMessage(plugin.getMessages().get("left-clan", "clan", clan.getName()));
            }
        });
    }

    private void handleDisband(Player player, String[] args) {
        if (!player.hasPermission("zmclans.clan.disband")) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return;
        }
        Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());
        if (optClan.isEmpty()) {
            player.sendMessage(plugin.getMessages().get("no-clan"));
            return;
        }
        Clan clan = optClan.get();
        if (!clan.getLeader().equals(player.getUniqueId()) && !plugin.getMemberService().hasPermission(player.getUniqueId(), ClanRank.Permission.DISBAND)) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return;
        }

        if (args.length >= 2 && args[1].equalsIgnoreCase("confirm")) {
            plugin.getClanService().disband(clan.getId());
            player.sendMessage(plugin.getMessages().get("clan-disbanded", "clan", clan.getName()));
            return;
        }

        String title = plugin.getMessages().get("gui-confirm-disband-title", "clan", clan.getName());
        plugin.getMenuManager().openConfirm(player, "disband", title, () -> {
            plugin.getClanService().disband(clan.getId());
            player.sendMessage(plugin.getMessages().get("clan-disbanded", "clan", clan.getName()));
        });
    }

    private void handleInfo(Player player, String[] args) {
        if (args.length >= 2) {
            String query = args[1];
            Optional<Clan> optClan = plugin.getClanService().findByName(query);
            if (optClan.isEmpty()) optClan = plugin.getClanService().findByTag(query);
            try {
                if (optClan.isEmpty()) {
                    optClan = plugin.getClanService().findById(UUID.fromString(query));
                }
            } catch (IllegalArgumentException ignored) {}

            if (optClan.isEmpty()) {
                player.sendMessage(plugin.getMessages().get("clan-not-found", "clan", query));
                return;
            }

            plugin.getMenuManager().openClanInfo(player, optClan.get(), "clan_list");
        } else {
            Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());
            if (optClan.isEmpty()) {
                player.sendMessage(plugin.getMessages().get("no-clan"));
                plugin.getMenuManager().openMainMenu(player);
                return;
            }

            plugin.getMenuManager().openClanInfo(player, optClan.get(), "clan_home");
        }
    }

    private void handleList(Player player, String[] args) {
        plugin.getMenuManager().openClanList(player, 0);
    }

    private void handleSetRank(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(plugin.getMessages().get("usage-setrank"));
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        String rankId = args[2].toLowerCase(Locale.ROOT);

        MemberService.RankResult result = plugin.getMemberService().assignRank(player.getUniqueId(), target.getUniqueId(), rankId);
        switch (result) {
            case OK -> {
                String rName = plugin.getRankService().getRank(rankId).map(ClanRank::getDisplayName).orElse(rankId);
                player.sendMessage(plugin.getMessages().get("rank-assigned", "player", args[1], "rank", rName));
            }
            case NO_PERMISSION -> player.sendMessage(plugin.getMessages().get("no-permission-rank"));
            case RANK_NOT_FOUND -> player.sendMessage(plugin.getMessages().get("rank-not-found", "rank", rankId));
            case SAME_RANK -> player.sendMessage(plugin.getMessages().get("same-rank", "player", args[1]));
            case CANNOT_ASSIGN_HIGHER -> player.sendMessage(plugin.getMessages().get("cannot-assign-own-rank"));
        }
    }

    private void handleSetHome(Player player) {
        if (!player.hasPermission("zmclans.clan.sethome")) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return;
        }
        HomeService.SetHomeResult res = plugin.getHomeService().setHome(player);
        switch (res) {
            case OK -> player.sendMessage(plugin.getMessages().get("home-set"));
            case NO_PERMISSION -> player.sendMessage(plugin.getMessages().get("no-permission-sethome"));
            case NO_CLAN -> player.sendMessage(plugin.getMessages().get("no-clan"));
        }
    }

    private void handleHome(Player player) {
        if (!player.hasPermission("zmclans.clan.home")) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return;
        }
        HomeService.TeleportResult res = plugin.getHomeService().teleport(player);
        switch (res) {
            case NO_CLAN -> player.sendMessage(plugin.getMessages().get("no-clan"));
            case NO_HOME -> player.sendMessage(plugin.getMessages().get("home-not-set"));
            case WORLD_UNLOADED -> player.sendMessage(plugin.getMessages().get("home-world-unloaded"));
            case NO_PERMISSION -> player.sendMessage(plugin.getMessages().get("no-permission-home"));
            default -> {}
        }
    }

    private void handleChat(Player player, String[] args) {
        if (!player.hasPermission("zmclans.clan.chat")) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return;
        }
        Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());
        if (optClan.isEmpty()) {
            player.sendMessage(plugin.getMessages().get("no-clan"));
            return;
        }

        if (args.length >= 2) {
            String msg = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
            plugin.getClanChatListener().sendClanMessage(player, optClan.get(), msg);
        } else {
            // Toggle clan chat mode
            boolean toggled = plugin.getClanChatListener().toggleChat(player.getUniqueId());
            player.sendMessage(plugin.getMessages().get(toggled ? "chat-toggled-on" : "chat-toggled-off"));
        }
    }

    private void handleFriendlyFire(Player player) {
        Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());
        if (optClan.isEmpty()) {
            player.sendMessage(plugin.getMessages().get("no-clan"));
            return;
        }
        if (!plugin.getMemberService().hasPermission(player.getUniqueId(), ClanRank.Permission.EDIT_SETTINGS)) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return;
        }
        Clan clan = optClan.get();
        clan.setFriendlyFire(!clan.isFriendlyFire());
        plugin.getClanService().saveAsync(clan);
        player.sendMessage(plugin.getMessages().get(clan.isFriendlyFire() ? "friendly-fire-enabled" : "friendly-fire-disabled"));
    }

    private void handleDescription(Player player, String[] args) {
        Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());
        if (optClan.isEmpty()) {
            player.sendMessage(plugin.getMessages().get("no-clan"));
            return;
        }
        if (!plugin.getMemberService().hasPermission(player.getUniqueId(), ClanRank.Permission.EDIT_DESCRIPTION)) {
            player.sendMessage(plugin.getMessages().get("no-permission-description"));
            return;
        }
        if (args.length < 2) {
            player.sendMessage(plugin.getMessages().get("usage-desc"));
            return;
        }

        String desc = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        if (desc.length() > 100) {
            player.sendMessage(plugin.getMessages().get("description-too-long"));
            return;
        }
        Clan clan = optClan.get();
        clan.setDescription(desc);
        plugin.getClanService().saveAsync(clan);
        player.sendMessage(plugin.getMessages().get("description-updated"));
    }

    private void handleModTag(Player player, String[] args) {
        if (!player.hasPermission("zmclans.clan.modtag")) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return;
        }

        if (args.length < 2) {
            player.sendMessage(plugin.getMessages().get("usage-modtag"));
            return;
        }

        String rawTag = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).trim();

        ClanService.ModTagResult res = plugin.getClanService().modifyTag(player, rawTag);
        switch (res) {
            case OK -> {
                Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());
                String formattedTag = optClan.map(Clan::getTag).orElse(rawTag);
                player.sendMessage(plugin.getMessages().get("tag-updated", "tag", formattedTag));
            }
            case NO_CLAN -> player.sendMessage(plugin.getMessages().get("no-clan"));
            case NO_PERMISSION -> player.sendMessage(plugin.getMessages().get("no-permission-modtag"));
            case TAG_INVALID -> player.sendMessage(plugin.getMessages().get("clan-tag-invalid"));
            case TAG_TAKEN -> {
                String clean = ColorUtil.strip(ColorUtil.colorize(rawTag));
                player.sendMessage(plugin.getMessages().get("clan-tag-taken", "tag", clean));
            }
        }
    }

    private void handleHelp(Player player) {
        player.sendMessage(plugin.getMessages().get("help-header"));
        for (String line : plugin.getMessages().getList("help-lines")) {
            player.sendMessage(line);
        }
        player.sendMessage(plugin.getMessages().get("help-footer"));
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (args.length == 1) {
            List<String> subs = List.of("menu", "create", "invite", "invites", "members", "settings", "stats", "accept", "deny", "kick", "leave", "disband", "info", "list", "setrank", "home", "sethome", "chat", "ff", "desc", "modtag", "help");
            return subs.stream().filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (sub.equals("invite") || sub.equals("kick")) {
                return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            }
            if (sub.equals("info") || sub.equals("accept") || sub.equals("deny")) {
                return plugin.getClanService().allClans().stream().map(Clan::getName).filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            }
        }
        if (args.length == 3 && (args[0].equalsIgnoreCase("setrank") || args[0].equalsIgnoreCase("rank") || args[0].equalsIgnoreCase("promote"))) {
            return plugin.getRankService().getAllRanks().stream().map(ClanRank::getId).filter(r -> r.toLowerCase(Locale.ROOT).startsWith(args[2].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }
}
