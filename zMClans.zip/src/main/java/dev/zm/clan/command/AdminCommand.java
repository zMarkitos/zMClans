package dev.zm.clan.command;

import dev.zm.clan.clan.model.Clan;
import dev.zm.clan.config.ColorUtil;
import dev.zm.clan.rank.model.ClanRank;
import dev.zm.clan.zMClans;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Admin command executor and tab completer for /zmclan.
 */
public final class AdminCommand implements CommandExecutor, TabCompleter {

    private final zMClans plugin;

    public AdminCommand(zMClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("zmclans.admin")) {
            sender.sendMessage(plugin.getMessages().get("no-permission"));
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload" -> handleReload(sender);
            case "disband", "delete" -> handleDisband(sender, args);
            case "setleader" -> handleSetLeader(sender, args);
            case "points" -> handlePoints(sender, args);
            case "info" -> handleInfo(sender, args);
            default -> sender.sendMessage(plugin.getMessages().get("unknown-command"));
        }

        return true;
    }

    private void handleReload(CommandSender sender) {
        plugin.getConfigManager().load();
        plugin.getMessages().load();
        plugin.getRankService().load();
        plugin.getClanService().loadAll();
        if (plugin.getMemberService() != null) {
            plugin.getMemberService().loadAll();
        }
        plugin.getMenuManager().loadAll();
        sender.sendMessage(plugin.getMessages().get("reload-success"));
    }

    private void handleDisband(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(plugin.getMessages().get("admin-disband-usage"));
            return;
        }
        Optional<Clan> optClan = plugin.getClanService().findByName(args[1]);
        if (optClan.isEmpty()) optClan = plugin.getClanService().findByTag(args[1]);

        if (optClan.isEmpty()) {
            sender.sendMessage(plugin.getMessages().get("clan-not-found", "clan", args[1]));
            return;
        }

        Clan clan = optClan.get();
        plugin.getClanService().disband(clan.getId());
        sender.sendMessage(plugin.getMessages().get("admin-disband-success", "clan", clan.getName()));
    }

    private void handleSetLeader(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(plugin.getMessages().get("admin-setleader-usage"));
            return;
        }

        Optional<Clan> optClan = plugin.getClanService().findByName(args[1]);
        if (optClan.isEmpty()) optClan = plugin.getClanService().findByTag(args[1]);

        if (optClan.isEmpty()) {
            sender.sendMessage(plugin.getMessages().get("clan-not-found", "clan", args[1]));
            return;
        }

        Clan clan = optClan.get();
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[2]);

        if (!clan.hasMember(target.getUniqueId())) {
            sender.sendMessage(plugin.getMessages().get("not-in-your-clan"));
            return;
        }

        String leaderRank = plugin.getRankService().getLeaderRank().map(ClanRank::getId).orElse("leader");
        String defaultRank = plugin.getRankService().getDefaultRank().map(ClanRank::getId).orElse("member");

        // Demote previous leader
        UUID oldLeader = clan.getLeader();
        if (plugin.getMemberService() != null) {
            plugin.getMemberService().getMember(oldLeader).ifPresent(m -> {
                m.setRankId(defaultRank);
                plugin.getMemberService().getMemberRepo().updateRank(oldLeader, defaultRank);
            });
            // Promote new leader
            plugin.getMemberService().getMember(target.getUniqueId()).ifPresent(m -> {
                m.setRankId(leaderRank);
                plugin.getMemberService().getMemberRepo().updateRank(target.getUniqueId(), leaderRank);
            });
        }

        clan.setLeader(target.getUniqueId());
        clan.setLeaderRankId(leaderRank);

        plugin.getClanService().saveAsync(clan);
        sender.sendMessage(plugin.getMessages().get("admin-setleader-success", "clan", clan.getName(), "player", target.getName() != null ? target.getName() : args[2]));
    }

    private void handlePoints(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(plugin.getMessages().get("admin-points-usage"));
            return;
        }

        String operation = args[1].toLowerCase(Locale.ROOT);
        Optional<Clan> optClan = plugin.getClanService().findByName(args[2]);
        if (optClan.isEmpty()) optClan = plugin.getClanService().findByTag(args[2]);

        if (optClan.isEmpty()) {
            sender.sendMessage(plugin.getMessages().get("clan-not-found", "clan", args[2]));
            return;
        }

        long amount;
        try {
            amount = Long.parseLong(args[3]);
        } catch (NumberFormatException e) {
            sender.sendMessage(plugin.getMessages().get("admin-points-invalid-amount"));
            return;
        }

        Clan clan = optClan.get();
        switch (operation) {
            case "add" -> clan.addPoints(amount);
            case "remove" -> clan.addPoints(-amount);
            case "set" -> clan.setPoints(amount);
            default -> {
                sender.sendMessage(plugin.getMessages().get("admin-points-invalid-op"));
                return;
            }
        }

        plugin.getClanService().saveAsync(clan);
        sender.sendMessage(plugin.getMessages().get("admin-points-success", "clan", clan.getName(), "amount", String.valueOf(clan.getPoints())));
    }

    private void handleInfo(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(plugin.getMessages().get("admin-info-usage"));
            return;
        }

        Optional<Clan> optClan = plugin.getClanService().findByName(args[1]);
        if (optClan.isEmpty()) optClan = plugin.getClanService().findByTag(args[1]);

        if (optClan.isEmpty()) {
            sender.sendMessage(plugin.getMessages().get("clan-not-found", "clan", args[1]));
            return;
        }

        Clan clan = optClan.get();
        OfflinePlayer leader = Bukkit.getOfflinePlayer(clan.getLeader());
        String leaderName = leader.getName() != null ? leader.getName() : clan.getLeader().toString();
        String dateStr = clan.getCreatedAt().toString().length() >= 10 ? clan.getCreatedAt().toString().substring(0, 10) : clan.getCreatedAt().toString();
        String homeStr = clan.getHome() != null ? clan.getHome().getWorldName() + " (" + (int)clan.getHome().getX() + ", " + (int)clan.getHome().getY() + ", " + (int)clan.getHome().getZ() + ")" : plugin.getMessages().get("admin-info-home-none");
        String ffStr = clan.isFriendlyFire() ? plugin.getMessages().get("admin-info-ff-enabled") : plugin.getMessages().get("admin-info-ff-disabled");

        sender.sendMessage(plugin.getMessages().get("admin-info-header"));
        sender.sendMessage(plugin.getMessages().get("admin-info-clan", "clan", clan.getName(), "tag", clan.getTag()));
        sender.sendMessage(plugin.getMessages().get("admin-info-uuid", "uuid", clan.getId().toString()));
        sender.sendMessage(plugin.getMessages().get("admin-info-leader", "player", leaderName, "uuid", clan.getLeader().toString()));
        sender.sendMessage(plugin.getMessages().get("admin-info-members", "amount", String.valueOf(clan.getMemberCount()), "max", String.valueOf(plugin.getConfigManager().getMaxMembers())));
        sender.sendMessage(plugin.getMessages().get("admin-info-points", "points", String.valueOf(clan.getPoints())));
        sender.sendMessage(plugin.getMessages().get("admin-info-friendly-fire", "status", ffStr));
        sender.sendMessage(plugin.getMessages().get("admin-info-created", "date", dateStr));
        sender.sendMessage(plugin.getMessages().get("admin-info-home", "home", homeStr));
        sender.sendMessage(plugin.getMessages().get("admin-info-footer"));
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(plugin.getMessages().get("admin-help-header"));
        for (String line : plugin.getMessages().getList("admin-help-lines")) {
            sender.sendMessage(line);
        }
        sender.sendMessage(plugin.getMessages().get("admin-help-footer"));
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("zmclans.admin")) return Collections.emptyList();
        if (args.length == 1) {
            return List.of("reload", "disband", "delete", "setleader", "points", "info", "help").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT)))
                    .collect(Collectors.toList());
        }
        if (args.length == 2) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (sub.equals("disband") || sub.equals("delete") || sub.equals("setleader") || sub.equals("info")) {
                return plugin.getClanService().allClans().stream().map(Clan::getName)
                        .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            }
            if (sub.equals("points")) {
                return List.of("add", "set", "remove").stream().filter(s -> s.startsWith(args[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            }
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("points")) {
            return plugin.getClanService().allClans().stream().map(Clan::getName)
                    .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[2].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("setleader")) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[2].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }
}
