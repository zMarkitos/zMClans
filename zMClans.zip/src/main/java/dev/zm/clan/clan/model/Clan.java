package dev.zm.clan.clan.model;

import dev.zm.clan.member.model.ClanMember;
import dev.zm.clan.zMClans;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Immutable-style domain model for a Clan.
 * Use the Builder to construct instances.
 * All mutations go through the service layer.
 */
public final class Clan {

    private final UUID id;
    private String name;
    private String tag;
    private String description;
    private UUID leader;
    private String leaderRankId;
    private final List<UUID> memberIds;
    private final Instant createdAt;

    // Clan settings
    private boolean friendlyFire;
    private boolean openInvitations;

    // Optional location (null if not set)
    private ClanHome home;

    // Points for leaderboard
    private long points;

    private Clan(Builder b) {
        this.id             = b.id;
        this.name           = b.name;
        this.tag            = b.tag;
        this.description    = b.description;
        this.leader         = b.leader;
        this.leaderRankId   = b.leaderRankId;
        this.memberIds      = new ArrayList<>(b.memberIds);
        this.createdAt      = b.createdAt;
        this.friendlyFire   = b.friendlyFire;
        this.openInvitations= b.openInvitations;
        this.home           = b.home;
        this.points         = b.points;
    }

    // ---- Read accessors -------------------------------------------
    public UUID getId()              { return id; }
    public String getName()          { return name; }
    public String getTag()           { return (tag != null && !tag.isBlank()) ? tag : name; }
    public String getRawTag()        { return tag != null ? tag : ""; }
    public boolean hasCustomTag()    { return tag != null && !tag.isBlank(); }
    public String getDescription()   { return description; }
    public UUID getLeader()          { return leader; }
    public String getLeaderRankId()  { return leaderRankId; }
    public List<UUID> getMemberIds() { return memberIds; }
    public Instant getCreatedAt()    { return createdAt; }
    public boolean isFriendlyFire()  { return friendlyFire; }
    public boolean isOpenInvitations(){ return openInvitations; }
    public ClanHome getHome()        { return home; }
    public long getPoints()          { return points; }
    public int getMemberCount()      { return memberIds.size(); }

    // ---- Mutations (called only from service layer) ---------------
    public void setName(String name)               { this.name = name; }
    public void setTag(String tag)                 { this.tag = tag; }
    public void setDescription(String desc)        { this.description = desc; }
    public void setLeader(UUID leader)             { this.leader = leader; }
    public void setLeaderRankId(String rankId)     { this.leaderRankId = rankId; }
    public void setFriendlyFire(boolean ff)        { this.friendlyFire = ff; }
    public void setOpenInvitations(boolean open)   { this.openInvitations = open; }
    public void setHome(ClanHome home)             { this.home = home; }
    public void addPoints(long delta)              { this.points = Math.max(0, this.points + delta); }
    public void setPoints(long points)             { this.points = Math.max(0, points); }

    public void addMember(UUID uuid) {
        if (!memberIds.contains(uuid)) memberIds.add(uuid);
    }

    public void removeMember(UUID uuid) {
        memberIds.remove(uuid);
    }

    public boolean hasMember(UUID uuid) {
        return memberIds.contains(uuid);
    }

    public List<ClanMember> getMembers() {
        if (zMClans.get() != null && zMClans.get().getMemberService() != null) {
            return zMClans.get().getMemberService().getMembersOfClan(id);
        }
        return List.of();
    }

    public Optional<ClanMember> getMember(UUID uuid) {
        if (zMClans.get() != null && zMClans.get().getMemberService() != null) {
            return zMClans.get().getMemberService().getMember(uuid);
        }
        return Optional.empty();
    }

    // ---- Builder -------------------------------------------------
    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private UUID id = UUID.randomUUID();
        private String name;
        private String tag;
        private String description = "";
        private UUID leader;
        private String leaderRankId = "leader";
        private List<UUID> memberIds = new ArrayList<>();
        private Instant createdAt = Instant.now();
        private boolean friendlyFire = false;
        private boolean openInvitations = false;
        private ClanHome home = null;
        private long points = 0L;

        public Builder id(UUID id)                   { this.id = id; return this; }
        public Builder name(String name)             { this.name = name; return this; }
        public Builder tag(String tag)               { this.tag = tag; return this; }
        public Builder description(String d)         { this.description = d; return this; }
        public Builder leader(UUID leader)           { this.leader = leader; return this; }
        public Builder leaderRankId(String r)        { this.leaderRankId = r; return this; }
        public Builder members(List<UUID> m)         { this.memberIds = new ArrayList<>(m); return this; }
        public Builder createdAt(Instant t)          { this.createdAt = t; return this; }
        public Builder friendlyFire(boolean ff)      { this.friendlyFire = ff; return this; }
        public Builder openInvitations(boolean o)    { this.openInvitations = o; return this; }
        public Builder home(ClanHome h)              { this.home = h; return this; }
        public Builder points(long p)                { this.points = p; return this; }

        public Clan build() {
            if (name == null || tag == null || leader == null)
                throw new IllegalStateException("Clan requires name, tag, and leader.");
            return new Clan(this);
        }
    }
}
