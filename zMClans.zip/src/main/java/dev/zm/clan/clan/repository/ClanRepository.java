package dev.zm.clan.clan.repository;

import dev.zm.clan.clan.model.Clan;
import dev.zm.clan.clan.model.ClanHome;
import dev.zm.clan.storage.DatabaseManager;

import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * All SQL operations for the {@code clans} table.
 * Returns {@link Optional} for single results and empty collections on failure.
 */
public final class ClanRepository {

    private final DatabaseManager db;
    private final Logger log;

    public ClanRepository(DatabaseManager db, Logger log) {
        this.db  = db;
        this.log = log;
    }

    // ---- Write operations ----------------------------------------

    public boolean insert(Clan clan) {
        String sql = """
            INSERT INTO clans(id,name,tag,description,leader,leader_rank,
                              friendly_fire,open_invite,home,points,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """;
        try (Connection con = db.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, clan.getId().toString());
            ps.setString(2, clan.getName());
            ps.setString(3, clan.getTag());
            ps.setString(4, clan.getDescription());
            ps.setString(5, clan.getLeader().toString());
            ps.setString(6, clan.getLeaderRankId());
            ps.setInt   (7, clan.isFriendlyFire() ? 1 : 0);
            ps.setInt   (8, clan.isOpenInvitations() ? 1 : 0);
            ps.setString(9, clan.getHome() != null ? clan.getHome().serialize() : null);
            ps.setLong  (10, clan.getPoints());
            ps.setLong  (11, clan.getCreatedAt().getEpochSecond());
            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            log.log(Level.SEVERE, "Failed to insert clan " + clan.getName(), e);
            return false;
        }
    }

    public boolean update(Clan clan) {
        String sql = """
            UPDATE clans SET name=?,tag=?,description=?,leader=?,leader_rank=?,
                             friendly_fire=?,open_invite=?,home=?,points=?
            WHERE id=?
        """;
        try (Connection con = db.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, clan.getName());
            ps.setString(2, clan.getTag());
            ps.setString(3, clan.getDescription());
            ps.setString(4, clan.getLeader().toString());
            ps.setString(5, clan.getLeaderRankId());
            ps.setInt   (6, clan.isFriendlyFire() ? 1 : 0);
            ps.setInt   (7, clan.isOpenInvitations() ? 1 : 0);
            ps.setString(8, clan.getHome() != null ? clan.getHome().serialize() : null);
            ps.setLong  (9, clan.getPoints());
            ps.setString(10, clan.getId().toString());
            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            log.log(Level.SEVERE, "Failed to update clan " + clan.getId(), e);
            return false;
        }
    }

    public boolean delete(UUID clanId) {
        try (Connection con = db.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM clans WHERE id=?")) {
            ps.setString(1, clanId.toString());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            log.log(Level.SEVERE, "Failed to delete clan " + clanId, e);
            return false;
        }
    }

    // ---- Read operations -----------------------------------------

    public Optional<Clan> findById(UUID id) {
        try (Connection con = db.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM clans WHERE id=?")) {
            ps.setString(1, id.toString());
            return Optional.ofNullable(mapRow(ps.executeQuery()));
        } catch (SQLException e) {
            log.log(Level.SEVERE, "Failed to findById " + id, e);
            return Optional.empty();
        }
    }

    public Optional<Clan> findByName(String name) {
        try (Connection con = db.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM clans WHERE LOWER(name)=LOWER(?)")) {
            ps.setString(1, name);
            return Optional.ofNullable(mapRow(ps.executeQuery()));
        } catch (SQLException e) {
            log.log(Level.SEVERE, "Failed to findByName " + name, e);
            return Optional.empty();
        }
    }

    public Optional<Clan> findByTag(String tag) {
        try (Connection con = db.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM clans WHERE LOWER(tag)=LOWER(?)")) {
            ps.setString(1, tag);
            return Optional.ofNullable(mapRow(ps.executeQuery()));
        } catch (SQLException e) {
            log.log(Level.SEVERE, "Failed to findByTag " + tag, e);
            return Optional.empty();
        }
    }

    public List<Clan> findAll() {
        List<Clan> list = new ArrayList<>();
        try (Connection con = db.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM clans");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Clan c = fromResultSet(rs);
                if (c != null) list.add(c);
            }
        } catch (SQLException e) {
            log.log(Level.SEVERE, "Failed to findAll clans", e);
        }
        return list;
    }

    public boolean existsByName(String name) {
        return findByName(name).isPresent();
    }

    public boolean existsByTag(String tag) {
        return findByTag(tag).isPresent();
    }

    // ---- Mapping -------------------------------------------------

    private Clan mapRow(ResultSet rs) throws SQLException {
        if (!rs.next()) return null;
        return fromResultSet(rs);
    }

    private Clan fromResultSet(ResultSet rs) throws SQLException {
        String homeRaw = rs.getString("home");
        ClanHome home  = (homeRaw != null && !homeRaw.isBlank()) ? ClanHome.deserialize(homeRaw) : null;

        return Clan.builder()
                .id(UUID.fromString(rs.getString("id")))
                .name(rs.getString("name"))
                .tag(rs.getString("tag"))
                .description(rs.getString("description"))
                .leader(UUID.fromString(rs.getString("leader")))
                .leaderRankId(rs.getString("leader_rank"))
                .friendlyFire(rs.getInt("friendly_fire") == 1)
                .openInvitations(rs.getInt("open_invite") == 1)
                .home(home)
                .points(rs.getLong("points"))
                .createdAt(Instant.ofEpochSecond(rs.getLong("created_at")))
                .build();
    }
}
