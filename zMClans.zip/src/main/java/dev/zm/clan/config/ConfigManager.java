package dev.zm.clan.config;

import dev.zm.clan.zMClans;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;

/**
 * Manages all plugin configuration files.
 * Provides typed accessors so no code outside this class
 * hard-codes config keys.
 */
public final class ConfigManager {

    private final zMClans plugin;
    private FileConfiguration config;

    // Cached values for hot-path access
    private String language;
    private int maxMembers;
    private double creationCost;
    private int inviteExpireSeconds;
    private int homeCooldown;
    private int homeWarmup;
    private boolean cancelOnMove;
    private boolean friendlyFire;
    private String storageType;

    public ConfigManager(zMClans plugin) {
        this.plugin = plugin;
    }

    /** Loads (or reloads) config.yml, copying defaults from the jar. */
    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        config = plugin.getConfig();
        parseValues();
    }

    private void parseValues() {
        language           = config.getString("language", "EN").toUpperCase();
        maxMembers         = config.getInt("clan.max-members", 20);
        creationCost       = config.getDouble("clan.creation-cost", 0.0);
        inviteExpireSeconds= config.getInt("invitations.expire-seconds", 120);
        homeCooldown       = config.getInt("home.teleport-cooldown", 5);
        homeWarmup         = config.getInt("home.teleport-warmup", 3);
        cancelOnMove       = config.getBoolean("home.cancel-on-move", true);
        friendlyFire       = config.getBoolean("clan.friendly-fire", false);
        storageType        = config.getString("storage.type", "SQLITE").toUpperCase();
    }

    // ------- Typed getters -----------------------------------------

    public FileConfiguration raw() { return config; }

    public String getLanguage()           { return language; }
    public int getMaxMembers()            { return maxMembers; }
    public double getCreationCost()       { return creationCost; }
    public int getInviteExpireSeconds()   { return inviteExpireSeconds; }
    public int getHomeCooldown()          { return homeCooldown; }
    public int getHomeWarmup()            { return homeWarmup; }
    public boolean isCancelOnMove()       { return cancelOnMove; }
    public boolean isFriendlyFire()       { return friendlyFire; }
    public String getStorageType()        { return storageType; }

    // SQLite
    public String getSqliteFile() {
        return config.getString("storage.sqlite.file", "database/clans.db");
    }

    // MySQL
    public String getMysqlHost()     { return config.getString("storage.mysql.host", "localhost"); }
    public int    getMysqlPort()     { return config.getInt("storage.mysql.port", 3306); }
    public String getMysqlDatabase() { return config.getString("storage.mysql.database", "zmclans"); }
    public String getMysqlUser()     { return config.getString("storage.mysql.username", "root"); }
    public String getMysqlPassword() { return config.getString("storage.mysql.password", ""); }
    public int    getMysqlPoolSize() { return config.getInt("storage.mysql.pool-size", 10); }
    public boolean isMysqlSsl()      { return config.getBoolean("storage.mysql.useSSL", false); }

    // Clan name validation
    public int getNameMinLength()  { return config.getInt("clan.name.min-length", 3); }
    public int getNameMaxLength()  { return config.getInt("clan.name.max-length", 20); }
    public String getNamePattern() { return config.getString("clan.name.allowed-pattern", "^[a-zA-Z0-9 _-]+$"); }
    public int getTagMinLength()   { return config.getInt("clan.tag.min-length", 2); }
    public int getTagMaxLength()   { return config.getInt("clan.tag.max-length", 6); }
    public String getTagPattern()  { return config.getString("clan.tag.allowed-pattern", "^[a-zA-Z0-9]+$"); }

    // Leaderboard
    public String getLeaderboardSortBy() { return config.getString("leaderboard.sort-by", "MEMBERS"); }
    public int getLeaderboardRefreshInterval() { return config.getInt("leaderboard.refresh-interval", 300); }

    // Chat & AutoSave
    public String getChatFormat()       { return config.getString("chat.format", "&8[&6{clan}&8] &7{player}&8: &f{message}"); }
    public int getAutoSaveInterval()    { return config.getInt("storage.auto-save-interval", 5); }

    // ------- Utility -----------------------------------------------

    /**
     * Loads a YAML file from the plugin data folder,
     * copying the default from the jar if absent.
     */
    public FileConfiguration loadYaml(String resourcePath) {
        File file = new File(plugin.getDataFolder(), resourcePath);
        if (!file.exists()) {
            plugin.saveResource(resourcePath, false);
        }
        FileConfiguration fc = YamlConfiguration.loadConfiguration(file);
        // Merge defaults from jar
        InputStream defaults = plugin.getResource(resourcePath);
        if (defaults != null) {
            fc.setDefaults(YamlConfiguration.loadConfiguration(
                    new InputStreamReader(defaults, StandardCharsets.UTF_8)));
        }
        return fc;
    }

    /** Saves a FileConfiguration back to disk. */
    public void saveYaml(FileConfiguration fc, String relativePath) {
        File file = new File(plugin.getDataFolder(), relativePath);
        try {
            fc.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save " + relativePath, e);
        }
    }
}
