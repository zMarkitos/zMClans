package dev.zm.clan.config;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.text.minimessage.tag.standard.StandardTags;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.md_5.bungee.api.ChatColor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Converts &amp; color codes, &#RRGGBB hex codes, and Adventure MiniMessage
 * tags (such as gradients, colors, bold, etc.) into Minecraft-formatted text safely.
 */
public final class ColorUtil {

    private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");

    /**
     * Safe MiniMessage resolver that strictly permits colors, decorations, gradients,
     * and rainbows, while rejecting any dangerous tags (click events, run commands, hover, etc.).
     */
    private static final TagResolver SAFE_TAG_RESOLVER = TagResolver.builder()
            .resolver(StandardTags.color())
            .resolver(StandardTags.decorations())
            .resolver(StandardTags.gradient())
            .resolver(StandardTags.rainbow())
            .resolver(StandardTags.reset())
            .build();

    private static final MiniMessage SAFE_MINI_MESSAGE = MiniMessage.builder()
            .tags(SAFE_TAG_RESOLVER)
            .build();

    private ColorUtil() {}

    /**
     * Translates MiniMessage tags, {@code &#RRGGBB} hex colors, and {@code &} color codes
     * into Minecraft section-formatted text.
     */
    public static String colorize(String text) {
        if (text == null || text.isEmpty()) return "";

        String result = text;

        // 1. Process MiniMessage tags safely if present (e.g., <gradient:...>, <b>, <color:...>)
        if (result.contains("<") && result.contains(">")) {
            try {
                Component comp = SAFE_MINI_MESSAGE.deserialize(result);
                result = LegacyComponentSerializer.legacySection().serialize(comp);
            } catch (Exception ignored) {
                // Ignore malformed MiniMessage and fall back to legacy hex parsing
            }
        }

        // 2. Replace &#RRGGBB with §x§R§R§G§G§B§B
        Matcher matcher = HEX_PATTERN.matcher(result);
        StringBuilder sb = new StringBuilder();
        while (matcher.find()) {
            String hex = matcher.group(1);
            StringBuilder replacement = new StringBuilder("§x");
            for (char c : hex.toCharArray()) {
                replacement.append('§').append(c);
            }
            matcher.appendReplacement(sb, replacement.toString());
        }
        matcher.appendTail(sb);

        // 3. Replace & codes
        return ChatColor.translateAlternateColorCodes('&', sb.toString());
    }

    /** Strips all color codes and tags from a string, returning pure clean text. */
    public static String strip(String text) {
        if (text == null) return "";
        return ChatColor.stripColor(colorize(text)).trim();
    }
}
