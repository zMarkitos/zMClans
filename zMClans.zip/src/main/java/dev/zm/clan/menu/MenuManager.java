package dev.zm.clan.menu;

import dev.zm.clan.clan.model.Clan;
import dev.zm.clan.config.ColorUtil;
import dev.zm.clan.zMClans;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.logging.Level;

/**
 * Central manager for all GUI menus.
 *
 * <h3>Architecture decision</h3>
 * Instead of coupling GUI rendering to business logic (as the reference does),
 * this manager:
 * <ol>
 *   <li>Loads a {@link MenuConfig} (pure data) from the relevant YAML file.</li>
 *   <li>Passes it to a {@link MenuBuilder} which constructs the Bukkit inventory.</li>
 *   <li>Registers the inventory in {@link MenuHolder} so {@link dev.zm.clan.listeners.MenuListener}
 *       can route clicks back through Java action handlers — not hardcoded in the GUI class.</li>
 * </ol>
 * This means: changing a menu YAML never requires touching Java code.
 */
public final class MenuManager {

    private final zMClans plugin;

    /** key (e.g. "no_clan") → loaded config */
    private final Map<String, MenuConfig> configs = new HashMap<>();

    /** All currently open menus — tracked for refresh/close */
    private final Map<UUID, ActiveMenu> openMenus = new HashMap<>();

    public MenuManager(zMClans plugin) {
        this.plugin = plugin;
    }

    // ---- Load ----------------------------------------------------

    /** Loads all GUI YAML files from the guis/ folder. */
    public void loadAll() {
        configs.clear();
        loadFile("guis/general.yml");
        loadFile("guis/members.yml");
        loadFile("guis/settings.yml");
        loadFile("guis/clanlist.yml");
        loadFile("guis/confirm.yml");
        loadFile("guis/invite.yml");
        loadFile("guis/invites.yml");
        loadFile("guis/member_manage.yml");
        loadFile("guis/clan_info.yml");
        plugin.getLogger().info("Loaded " + configs.size() + " menu configurations.");
    }

    private void loadFile(String path) {
        try {
            FileConfiguration fc = plugin.getConfigManager().loadYaml(path);
            for (String key : fc.getKeys(false)) {
                ConfigurationSection section = fc.getConfigurationSection(key);
                if (section == null) continue;
                MenuConfig mc = MenuConfig.parse(key, section);
                configs.put(key, mc);
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Failed to load GUI file: " + path, e);
        }
    }

    // ---- Open menus ----------------------------------------------

    public void openMainMenu(Player player) {
        boolean inClan = plugin.getClanService().isInClan(player.getUniqueId());
        String key = inClan ? "clan_home" : "no_clan";
        open(player, key, 0, buildPlaceholders(player));
    }

    public void openMembersMenu(Player player, int page) {
        openMembersMenu(player, page, null);
    }

    public void openMembersMenu(Player player, int page, UUID targetClanId) {
        ActiveMenu active = new ActiveMenu("clan_members", null, page);
        active.setTargetClanId(targetClanId);
        openMenus.put(player.getUniqueId(), active);

        Map<String, String> ph = buildPlaceholders(player);
        if (targetClanId != null) {
            plugin.getClanService().findById(targetClanId).ifPresent(c -> populateClanPlaceholders(player, c, ph));
        }

        MenuConfig cfg = configs.get("clan_members");
        if (cfg == null) {
            player.sendMessage(plugin.getMessages().get("gui-error-no-menu"));
            return;
        }
        MenuBuilder.buildAndOpen(plugin, player, cfg, ph, this);
    }

    public void openClanInfo(Player player, Clan clan, String backMenu) {
        if (clan == null) {
            Optional<Clan> opt = plugin.getClanService().findByPlayer(player.getUniqueId());
            if (opt.isEmpty()) {
                player.sendMessage(plugin.getMessages().get("no-clan"));
                return;
            }
            clan = opt.get();
        }

        Map<String, String> ph = buildPlaceholders(player);
        populateClanPlaceholders(player, clan, ph);

        ActiveMenu active = new ActiveMenu("clan_info", null, 0);
        active.setTargetClanId(clan.getId());
        active.setBackMenuKey(backMenu != null ? backMenu : "clan_list");
        openMenus.put(player.getUniqueId(), active);

        MenuConfig cfg = configs.get("clan_info");
        if (cfg == null) {
            player.sendMessage(plugin.getMessages().get("gui-error-no-menu"));
            return;
        }
        MenuBuilder.buildAndOpen(plugin, player, cfg, ph, this);
    }

    public void openSettingsMenu(Player player) {
        open(player, "clan_settings", 0, buildPlaceholders(player));
    }

    public void openClanList(Player player, int page) {
        open(player, "clan_list", page, buildPlaceholders(player));
    }

    public void openInviteMenu(Player player, int page) {
        open(player, "clan_invite", page, buildPlaceholders(player));
    }

    public void openInvitesMenu(Player player, int page) {
        open(player, "clan_invites", page, buildPlaceholders(player));
    }

    public void openStatsMenu(Player player) {
        Optional<Clan> opt = plugin.getClanService().findByPlayer(player.getUniqueId());
        if (opt.isPresent()) {
            openClanInfo(player, opt.get(), "clan_home");
        } else {
            player.sendMessage(plugin.getMessages().get("no-clan"));
        }
    }

    public void openMemberManage(Player player, UUID targetUuid) {
        Map<String, String> ph = buildPlaceholders(player);
        org.bukkit.OfflinePlayer target = plugin.getServer().getOfflinePlayer(targetUuid);
        ph.put("target_uuid", targetUuid.toString());
        ph.put("target_name", target.getName() != null ? target.getName() : "Unknown");
        ph.put("target_status", target.isOnline() ? "&aOnline" : "&cOffline");

        plugin.getMemberService().getMember(targetUuid).ifPresent(m -> {
            ph.put("target_rank", m.getRankId());
            String joinStr = m.getJoinedAt().toString();
            ph.put("target_joined", joinStr.length() >= 10 ? joinStr.substring(0, 10) : joinStr);
        });

        ActiveMenu active = new ActiveMenu("member_manage", null, 0);
        active.setTargetUuid(targetUuid);
        openMenus.put(player.getUniqueId(), active);

        MenuConfig cfg = configs.get("member_manage");
        if (cfg == null) {
            player.sendMessage(plugin.getMessages().get("gui-error-no-menu"));
            return;
        }
        MenuBuilder.buildAndOpen(plugin, player, cfg, ph, this);
    }

    public void openConfirm(Player player, String actionKey, String description, Runnable onConfirm) {
        Map<String, String> ph = buildPlaceholders(player);
        ph.put("action", actionKey);
        ph.put("action_description", description);
        // Store the confirm callback
        openMenus.put(player.getUniqueId(), new ActiveMenu("confirm", onConfirm));

        MenuConfig cfg = configs.get("confirm");
        if (cfg == null) {
            player.sendMessage(plugin.getMessages().get("gui-error-no-menu"));
            return;
        }
        MenuBuilder.buildAndOpen(plugin, player, cfg, ph, this);
    }

    // ---- Generic open --------------------------------------------

    private void open(Player player, String key, int page, Map<String, String> placeholders) {
        MenuConfig cfg = configs.get(key);
        if (cfg == null) {
            player.sendMessage(plugin.getMessages().get("gui-error-no-menu"));
            return;
        }
        openMenus.put(player.getUniqueId(), new ActiveMenu(key, null, page));
        MenuBuilder.buildAndOpen(plugin, player, cfg, placeholders, this);
    }

    // ---- Callbacks -----------------------------------------------

    public void onClose(Player player) {
        openMenus.remove(player.getUniqueId());
    }

    public Optional<ActiveMenu> getOpenMenu(Player player) {
        return Optional.ofNullable(openMenus.get(player.getUniqueId()));
    }

    public Optional<MenuConfig> getConfig(String key) {
        return Optional.ofNullable(configs.get(key));
    }

    // ---- Placeholders --------------------------------------------

    private Map<String, String> buildPlaceholders(Player player) {
        Map<String, String> ph = new HashMap<>();
        ph.put("player", player.getName());

        ph.put("creation_cost", plugin.getConfigManager().getCreationCost() > 0 ? ("$" + plugin.getConfigManager().getCreationCost()) : "Free");
        boolean chatOn = plugin.getClanChatListener() != null && plugin.getClanChatListener().isInClanChat(player.getUniqueId());
        ph.put("chat_status", chatOn ? "&#55FFAA&lON" : "&c&lOFF");

        plugin.getClanService().findByPlayer(player.getUniqueId()).ifPresent(clan -> {
            populateClanPlaceholders(player, clan, ph);
        });

        // PlaceholderAPI
        plugin.getHookManager().parsePapi(player, ph);

        return ph;
    }

    public void populateClanPlaceholders(Player player, Clan clan, Map<String, String> ph) {
        if (clan == null) return;
        ph.put("clan", clan.getName());
        ph.put("tag", clan.getTag());
        ph.put("clan_id", clan.getId().toString());

        org.bukkit.OfflinePlayer leaderOp = plugin.getServer().getOfflinePlayer(clan.getLeader());
        String leaderName = leaderOp.getName() != null ? leaderOp.getName() : "Unknown";
        ph.put("leader", leaderName);
        ph.put("leader_uuid", clan.getLeader().toString());
        ph.put("leader_status", leaderOp.isOnline() ? "&#55FFAAOnline" : "&cOffline");

        int max = plugin.getConfigManager().getMaxMembers();
        ph.put("members", String.valueOf(clan.getMemberCount()));
        ph.put("max", String.valueOf(max));
        int pct = max > 0 ? (int) Math.round(((double) clan.getMemberCount() / max) * 100) : 0;
        ph.put("capacity_percent", String.valueOf(pct));

        ph.put("points", String.valueOf(clan.getPoints()));
        ph.put("description", clan.getDescription().isBlank() ? "Ninguna descripción" : clan.getDescription());

        String cDate = clan.getCreatedAt().toString();
        ph.put("created_at", cDate.length() >= 10 ? cDate.substring(0, 10) : cDate);

        // Ranking
        List<Clan> all = plugin.getClanService().findAll();
        int rankPos = 1;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).getId().equals(clan.getId())) {
                rankPos = i + 1;
                break;
            }
        }
        ph.put("ranking", String.valueOf(rankPos));
        ph.put("position", String.valueOf(rankPos));
        ph.put("total_clans", String.valueOf(all.size()));

        // Friendly fire & open invites
        ph.put("friendly_fire_status", clan.isFriendlyFire() ? "&#55FFAA&lACTIVADO" : "&c&lDESACTIVADO");
        ph.put("friendly_fire_desc", clan.isFriendlyFire() ? "&aPermitido el combate" : "&cProtegido contra daño");
        ph.put("open_invite_status", clan.isOpenInvitations() ? "&#55FFAA&lABIERTAS" : "&c&lCERRADAS");
        ph.put("open_invite_desc", clan.isOpenInvitations() ? "&aCualquier miembro invita" : "&eSolo oficiales y líderes");

        // Home
        boolean isMember = plugin.getClanService().findByPlayer(player.getUniqueId())
                .map(c -> c.getId().equals(clan.getId())).orElse(false);
        if (isMember) {
            ph.put("home_location", clan.getHome() != null
                    ? (clan.getHome().getWorldName() + " (" + (int) clan.getHome().getX() + ", " + (int) clan.getHome().getY() + ", " + (int) clan.getHome().getZ() + ")")
                    : "&cNo establecido");
            ph.put("home_action_line", clan.getHome() != null
                    ? "&#55FFAA➜ &fClic para teletransportarse al hogar"
                    : "&7(Establece un hogar con /clan sethome)");
        } else {
            ph.put("home_location", "&cProtegido &8(&7Oculto por seguridad táctica&8)");
            ph.put("home_action_line", "&7(Solo visible para miembros de este clan)");
        }
    }

    public zMClans getPlugin() { return plugin; }
}
