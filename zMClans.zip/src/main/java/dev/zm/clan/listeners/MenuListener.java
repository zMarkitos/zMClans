package dev.zm.clan.listeners;

import dev.zm.clan.clan.model.Clan;
import dev.zm.clan.invitation.model.Invitation;
import dev.zm.clan.member.model.ClanMember;
import dev.zm.clan.menu.ActiveMenu;
import dev.zm.clan.menu.ItemConfig;
import dev.zm.clan.menu.MenuHolder;
import dev.zm.clan.rank.model.ClanRank;
import dev.zm.clan.service.HomeService;
import dev.zm.clan.service.InviteService;
import dev.zm.clan.service.MemberService;
import dev.zm.clan.zMClans;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

import java.util.*;

/**
 * Handles interactions inside all zMClans GUI menus.
 * Fully protects menus from drag/item exploits, routes all button clicks,
 * and uses localized messages without hardcoding.
 */
public final class MenuListener implements Listener {

    private final zMClans plugin;

    public MenuListener(zMClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof MenuHolder) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof MenuHolder holder)) {
            return;
        }

        // Cancel all clicks in and around the menu to avoid exploits
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        int slot = event.getRawSlot();
        if (slot < 0 || slot >= event.getInventory().getSize()) {
            return;
        }

        boolean rightClick = event.isRightClick();

        // 1. Check if the clicked slot is a dynamic pagination item
        Object data = holder.getSlotData(slot);
        if (data != null) {
            handleDynamicSlotClick(player, holder, data, rightClick);
            return;
        }

        // 2. Otherwise check static item action
        ItemConfig itemConfig = holder.getSlotAction(slot);
        if (itemConfig == null) {
            return;
        }

        String action = itemConfig.getAction();
        if (action == null || action.isBlank() || "NONE".equalsIgnoreCase(action)) {
            return;
        }

        handleAction(player, holder, action, rightClick);
    }

    private void handleDynamicSlotClick(Player player, MenuHolder holder, Object data, boolean rightClick) {
        // A) Clicked a member in clan_members
        if (data instanceof ClanMember member) {
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
            plugin.getMenuManager().openMemberManage(player, member.getPlayerUUID());
            return;
        }

        // B) Clicked a player in clan_invite (to invite them)
        if (data instanceof UUID targetPlayerUuid) {
            Player target = Bukkit.getPlayer(targetPlayerUuid);
            if (target == null || !target.isOnline()) {
                player.sendMessage(plugin.getMessages().get("player-not-found", "player", "Unknown"));
                return;
            }

            InviteService.InviteResult result = plugin.getInviteService().sendInvite(player.getUniqueId(), targetPlayerUuid);
            switch (result) {
                case OK -> {
                    player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
                    player.sendMessage(plugin.getMessages().get("invite-sent", "player", target.getName()));
                    plugin.getClanService().findByPlayer(player.getUniqueId()).ifPresent(clan -> {
                        target.sendMessage(plugin.getMessages().get("invite-received", "clan", clan.getName(), "sender", player.getName()));
                    });
                    // Refresh invite menu
                    plugin.getMenuManager().openInviteMenu(player, holder.getPage());
                }
                case NO_PERMISSION -> player.sendMessage(plugin.getMessages().get("no-permission"));
                case ALREADY_HAS_CLAN -> player.sendMessage(plugin.getMessages().get("invite-player-has-clan", "player", target.getName()));
                case ALREADY_INVITED -> player.sendMessage(plugin.getMessages().get("invite-already-sent", "player", target.getName()));
                case CLAN_FULL -> {
                    Clan c = plugin.getClanService().findByPlayer(player.getUniqueId()).orElse(null);
                    String cur = c != null ? String.valueOf(c.getMemberCount()) : "0";
                    player.sendMessage(plugin.getMessages().get("invite-clan-full", "amount", cur, "max", String.valueOf(plugin.getConfigManager().getMaxMembers())));
                }
                default -> player.sendMessage(plugin.getMessages().get("player-not-found", "player", target.getName()));
            }
            return;
        }

        // C) Clicked an invitation in clan_invites
        if (data instanceof Invitation inv) {
            if (rightClick) {
                // Deny invitation
                plugin.getInviteService().deny(player.getUniqueId(), inv.getClanId());
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
                plugin.getClanService().findById(inv.getClanId()).ifPresentOrElse(
                        clan -> player.sendMessage(plugin.getMessages().get("invite-denied-receiver", "clan", clan.getName())),
                        () -> player.sendMessage(plugin.getMessages().get("invite-denied"))
                );
                plugin.getMenuManager().openInvitesMenu(player, holder.getPage());
            } else {
                // Accept invitation
                if (plugin.getInviteService().accept(player.getUniqueId(), inv.getClanId())) {
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
                    Clan clan = plugin.getClanService().findById(inv.getClanId()).orElse(null);
                    player.sendMessage(plugin.getMessages().get("invite-accepted-receiver", "clan", clan != null ? clan.getName() : ""));
                    plugin.getMenuManager().openMainMenu(player);
                } else {
                    player.sendMessage(plugin.getMessages().get("invite-expired", "clan", ""));
                    plugin.getMenuManager().openInvitesMenu(player, holder.getPage());
                }
            }
            return;
        }

        // D) Clicked a clan in clan_list
        if (data instanceof Clan clan) {
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
            plugin.getMenuManager().openClanInfo(player, clan, "clan_list");
            return;
        }
    }

    private void handleAction(Player player, MenuHolder holder, String action, boolean rightClick) {
        if ("CLOSE".equalsIgnoreCase(action)) {
            player.closeInventory();
            return;
        }

        if ("OPEN_CLANS".equalsIgnoreCase(action)) {
            plugin.getMenuManager().openClanList(player, 0);
            return;
        }

        if ("CREATE_CLAN".equalsIgnoreCase(action)) {
            player.closeInventory();
            player.sendMessage(plugin.getMessages().get("gui-create-clan-instruction"));
            return;
        }

        if ("SHOW_HELP".equalsIgnoreCase(action)) {
            player.closeInventory();
            player.performCommand("clan help");
            return;
        }

        if (action.startsWith("CMD_PLAYER:")) {
            player.closeInventory();
            String cmd = action.substring("CMD_PLAYER:".length()).trim().replaceFirst("^/", "");
            player.performCommand(cmd);
            return;
        }

        if (action.startsWith("CMD_CONSOLE:")) {
            player.closeInventory();
            String cmd = action.substring("CMD_CONSOLE:".length()).trim().replace("{player}", player.getName());
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            return;
        }

        if ("EDIT_DESCRIPTION".equalsIgnoreCase(action)) {
            player.closeInventory();
            player.sendMessage(plugin.getMessages().get("gui-desc-edit-instruction"));
            return;
        }

        if (action.startsWith("OPEN_GUI:")) {
            String guiName = action.substring("OPEN_GUI:".length()).trim().toLowerCase(Locale.ROOT);
            switch (guiName) {
                case "clan_home", "general" -> plugin.getMenuManager().openMainMenu(player);
                case "no_clan" -> plugin.getMenuManager().openMainMenu(player);
                case "clan_members", "members" -> plugin.getMenuManager().openMembersMenu(player, 0);
                case "clan_settings", "settings" -> plugin.getMenuManager().openSettingsMenu(player);
                case "clan_list", "clanlist" -> plugin.getMenuManager().openClanList(player, 0);
                case "clan_invite", "invite" -> plugin.getMenuManager().openInviteMenu(player, 0);
                case "clan_invites", "invites" -> plugin.getMenuManager().openInvitesMenu(player, 0);
                case "clan_stats", "stats", "clan_info" -> plugin.getMenuManager().openStatsMenu(player);
                default -> player.sendMessage(plugin.getMessages().get("gui-error-no-menu"));
            }
            return;
        }

        if (action.startsWith("OPEN_MEMBER_MANAGE:")) {
            String rawUuid = action.substring("OPEN_MEMBER_MANAGE:".length()).trim();
            try {
                UUID u = UUID.fromString(rawUuid);
                plugin.getMenuManager().openMemberManage(player, u);
            } catch (IllegalArgumentException ignored) {}
            return;
        }

        if (action.startsWith("OPEN_CLAN_MEMBERS:")) {
            String rawId = action.substring("OPEN_CLAN_MEMBERS:".length()).trim();
            UUID clanId = null;
            try {
                clanId = UUID.fromString(rawId);
            } catch (IllegalArgumentException ignored) {}
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
            plugin.getMenuManager().openMembersMenu(player, 0, clanId);
            return;
        }

        if (action.startsWith("OPEN_CLAN_INFO:")) {
            String rawId = action.substring("OPEN_CLAN_INFO:".length()).trim();
            Optional<Clan> optClan = Optional.empty();
            try {
                UUID u = UUID.fromString(rawId);
                optClan = plugin.getClanService().findById(u);
            } catch (IllegalArgumentException e) {
                optClan = plugin.getClanService().findByName(rawId);
                if (optClan.isEmpty()) optClan = plugin.getClanService().findByTag(rawId);
            }
            if (optClan.isPresent()) {
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
                plugin.getMenuManager().openClanInfo(player, optClan.get(), "clan_list");
            } else {
                player.sendMessage(plugin.getMessages().get("clan-not-found", "clan", rawId));
            }
            return;
        }

        if ("BACK_PREVIOUS".equalsIgnoreCase(action)) {
            ActiveMenu active = plugin.getMenuManager().getOpenMenu(player).orElse(null);
            String backKey = active != null ? active.getBackMenuKey() : null;
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
            if ("clan_list".equalsIgnoreCase(backKey)) {
                plugin.getMenuManager().openClanList(player, active != null ? active.getBackPage() : 0);
            } else if ("clan_home".equalsIgnoreCase(backKey)) {
                plugin.getMenuManager().openMainMenu(player);
            } else if ("clan_info".equalsIgnoreCase(backKey)) {
                if (active != null && active.getTargetClanId() != null) {
                    plugin.getClanService().findById(active.getTargetClanId()).ifPresentOrElse(
                            c -> plugin.getMenuManager().openClanInfo(player, c, "clan_list"),
                            () -> plugin.getMenuManager().openMainMenu(player)
                    );
                } else {
                    plugin.getMenuManager().openMainMenu(player);
                }
            } else {
                plugin.getMenuManager().openMainMenu(player);
            }
            return;
        }

        if ("CLAN_HOME_OR_INFO".equalsIgnoreCase(action)) {
            ActiveMenu active = plugin.getMenuManager().getOpenMenu(player).orElse(null);
            UUID clanId = active != null ? active.getTargetClanId() : null;
            boolean isMember = false;
            if (clanId != null) {
                isMember = plugin.getClanService().findByPlayer(player.getUniqueId())
                        .map(c -> c.getId().equals(clanId)).orElse(false);
            }
            if (isMember) {
                player.closeInventory();
                HomeService.TeleportResult res = plugin.getHomeService().teleport(player);
                switch (res) {
                    case NO_CLAN -> player.sendMessage(plugin.getMessages().get("no-clan"));
                    case NO_HOME -> player.sendMessage(plugin.getMessages().get("home-not-set"));
                    case WORLD_UNLOADED -> player.sendMessage(plugin.getMessages().get("home-world-unloaded"));
                    case NO_PERMISSION -> player.sendMessage(plugin.getMessages().get("no-permission-home"));
                    default -> {}
                }
            } else {
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 0.8f);
            }
            return;
        }

        if ("TOGGLE_CHAT".equalsIgnoreCase(action)) {
            if (!plugin.getClanService().isInClan(player.getUniqueId())) {
                player.sendMessage(plugin.getMessages().get("no-clan"));
                return;
            }
            boolean enabled = plugin.getClanChatListener().toggleChat(player.getUniqueId());
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
            player.sendMessage(plugin.getMessages().get(enabled ? "chat-toggled-on" : "chat-toggled-off"));
            plugin.getMenuManager().openMainMenu(player);
            return;
        }

        if ("CLAN_HOME_OR_SETHOME".equalsIgnoreCase(action)) {
            if (rightClick) {
                // Set home
                HomeService.SetHomeResult res = plugin.getHomeService().setHome(player);
                switch (res) {
                    case OK -> {
                        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
                        player.sendMessage(plugin.getMessages().get("home-set"));
                        plugin.getMenuManager().openMainMenu(player);
                    }
                    case NO_PERMISSION -> player.sendMessage(plugin.getMessages().get("no-permission-sethome"));
                    case NO_CLAN -> player.sendMessage(plugin.getMessages().get("no-clan"));
                }
            } else {
                // Teleport to home
                player.closeInventory();
                HomeService.TeleportResult res = plugin.getHomeService().teleport(player);
                switch (res) {
                    case NO_CLAN -> player.sendMessage(plugin.getMessages().get("no-clan"));
                    case NO_HOME -> player.sendMessage(plugin.getMessages().get("home-not-set"));
                    case WORLD_UNLOADED -> player.sendMessage(plugin.getMessages().get("home-world-unloaded"));
                    case NO_PERMISSION -> player.sendMessage(plugin.getMessages().get("no-permission-home"));
                    default -> {}
                }
            }
            return;
        }

        if ("TOGGLE_FRIENDLY_FIRE".equalsIgnoreCase(action) || "TOGGLE_SETTING:friendly_fire".equalsIgnoreCase(action)) {
            if (!plugin.getMemberService().hasPermission(player.getUniqueId(), ClanRank.Permission.EDIT_SETTINGS)) {
                player.sendMessage(plugin.getMessages().get("no-permission"));
                return;
            }
            Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());
            optClan.ifPresent(clan -> {
                clan.setFriendlyFire(!clan.isFriendlyFire());
                plugin.getClanService().saveAsync(clan);
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
                player.sendMessage(plugin.getMessages().get(clan.isFriendlyFire() ? "friendly-fire-enabled" : "friendly-fire-disabled"));
                plugin.getMenuManager().openSettingsMenu(player);
            });
            return;
        }

        if ("TOGGLE_OPEN_INVITES".equalsIgnoreCase(action) || "TOGGLE_SETTING:open_invitations".equalsIgnoreCase(action)) {
            if (!plugin.getMemberService().hasPermission(player.getUniqueId(), ClanRank.Permission.EDIT_SETTINGS)) {
                player.sendMessage(plugin.getMessages().get("no-permission"));
                return;
            }
            Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());
            optClan.ifPresent(clan -> {
                clan.setOpenInvitations(!clan.isOpenInvitations());
                plugin.getClanService().saveAsync(clan);
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
                plugin.getMenuManager().openSettingsMenu(player);
            });
            return;
        }

        if ("CONFIRM".equalsIgnoreCase(action) || "CONFIRM_ACTION".equalsIgnoreCase(action)) {
            Runnable callback = holder.getConfirmAction();
            player.closeInventory();
            if (callback != null) {
                callback.run();
            }
            return;
        }

        if ("CANCEL".equalsIgnoreCase(action)) {
            plugin.getMenuManager().openMainMenu(player);
            return;
        }

        if ("PAGE_NEXT".equalsIgnoreCase(action) || "NEXT_PAGE".equalsIgnoreCase(action)) {
            ActiveMenu active = plugin.getMenuManager().getOpenMenu(player).orElse(null);
            if (active != null && active.getPage() < holder.getMaxPages() - 1) {
                active.setPage(active.getPage() + 1);
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.2f);
                refreshMenuPage(player, active);
            }
            return;
        }

        if ("PAGE_PREV".equalsIgnoreCase(action) || "PREV_PAGE".equalsIgnoreCase(action)) {
            ActiveMenu active = plugin.getMenuManager().getOpenMenu(player).orElse(null);
            if (active != null && active.getPage() > 0) {
                active.setPage(active.getPage() - 1);
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.2f);
                refreshMenuPage(player, active);
            }
            return;
        }

        // Member Management Actions
        if ("MEMBER_PROMOTE".equalsIgnoreCase(action)) {
            handleMemberPromote(player);
            return;
        }

        if ("MEMBER_DEMOTE".equalsIgnoreCase(action)) {
            handleMemberDemote(player);
            return;
        }

        if ("MEMBER_KICK".equalsIgnoreCase(action)) {
            handleMemberKick(player);
            return;
        }

        if ("MEMBER_TRANSFER_LEADER".equalsIgnoreCase(action)) {
            handleMemberTransferLeader(player);
            return;
        }

        if ("CLAN_HOME".equalsIgnoreCase(action)) {
            player.closeInventory();
            HomeService.TeleportResult res = plugin.getHomeService().teleport(player);
            switch (res) {
                case NO_CLAN -> player.sendMessage(plugin.getMessages().get("no-clan"));
                case NO_HOME -> player.sendMessage(plugin.getMessages().get("home-not-set"));
                case WORLD_UNLOADED -> player.sendMessage(plugin.getMessages().get("home-world-unloaded"));
                case NO_PERMISSION -> player.sendMessage(plugin.getMessages().get("no-permission-home"));
                default -> {}
            }
            return;
        }

        if ("CLAN_SETHOME".equalsIgnoreCase(action)) {
            HomeService.SetHomeResult res = plugin.getHomeService().setHome(player);
            switch (res) {
                case OK -> {
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
                    player.sendMessage(plugin.getMessages().get("home-set"));
                }
                case NO_PERMISSION -> player.sendMessage(plugin.getMessages().get("no-permission-sethome"));
                case NO_CLAN -> player.sendMessage(plugin.getMessages().get("no-clan"));
            }
            player.closeInventory();
            return;
        }

        if ("CLAN_LEAVE".equalsIgnoreCase(action)) {
            Optional<Clan> currentClan = plugin.getClanService().findByPlayer(player.getUniqueId());
            if (currentClan.isEmpty()) {
                player.sendMessage(plugin.getMessages().get("no-clan"));
                return;
            }
            if (currentClan.get().getLeader().equals(player.getUniqueId())) {
                player.sendMessage(plugin.getMessages().get("leader-cannot-leave"));
                return;
            }
            String title = plugin.getMessages().get("gui-confirm-leave-title");
            plugin.getMenuManager().openConfirm(player, "leave", title, () -> {
                Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());
                if (optClan.isPresent()) {
                    String cName = optClan.get().getName();
                    if (plugin.getMemberService().leave(player)) {
                        player.sendMessage(plugin.getMessages().get("left-clan", "clan", cName));
                    } else {
                        player.sendMessage(plugin.getMessages().get("leader-cannot-leave"));
                    }
                }
            });
            return;
        }

        if ("CLAN_DISBAND".equalsIgnoreCase(action)) {
            if (!plugin.getMemberService().hasPermission(player.getUniqueId(), ClanRank.Permission.DISBAND)) {
                player.sendMessage(plugin.getMessages().get("no-permission"));
                return;
            }
            Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());
            if (optClan.isEmpty()) {
                player.sendMessage(plugin.getMessages().get("no-clan"));
                return;
            }
            Clan clan = optClan.get();
            String title = plugin.getMessages().get("gui-confirm-disband-title", "clan", clan.getName());
            plugin.getMenuManager().openConfirm(player, "disband", title, () -> {
                plugin.getClanService().disband(clan.getId());
                player.sendMessage(plugin.getMessages().get("clan-disbanded", "clan", clan.getName()));
            });
        }
    }

    private void refreshMenuPage(Player player, ActiveMenu active) {
        String key = active.getMenuKey();
        switch (key) {
            case "clan_members" -> plugin.getMenuManager().openMembersMenu(player, active.getPage(), active.getTargetClanId());
            case "clan_list" -> plugin.getMenuManager().openClanList(player, active.getPage());
            case "clan_invite" -> plugin.getMenuManager().openInviteMenu(player, active.getPage());
            case "clan_invites" -> plugin.getMenuManager().openInvitesMenu(player, active.getPage());
        }
    }

    private void handleMemberPromote(Player player) {
        ActiveMenu active = plugin.getMenuManager().getOpenMenu(player).orElse(null);
        if (active == null || active.getTargetUuid() == null) return;
        UUID targetUuid = active.getTargetUuid();

        Optional<ClanMember> optTarget = plugin.getMemberService().getMember(targetUuid);
        if (optTarget.isEmpty()) return;

        ClanMember target = optTarget.get();
        List<ClanRank> ranks = new ArrayList<>(plugin.getRankService().allRanks());
        ranks.sort(Comparator.comparingInt(ClanRank::getPriority));

        // Find next higher rank
        ClanRank nextRank = null;
        for (ClanRank r : ranks) {
            ClanRank curRank = plugin.getRankService().getRank(target.getRankId()).orElse(null);
            if (curRank != null && r.getPriority() > curRank.getPriority() && !r.isLeader()) {
                nextRank = r;
                break;
            }
        }

        if (nextRank == null) {
            player.sendMessage(plugin.getMessages().get("rank-highest"));
            return;
        }

        MemberService.RankResult res = plugin.getMemberService().assignRank(player.getUniqueId(), targetUuid, nextRank.getId());
        if (res == MemberService.RankResult.OK) {
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            player.sendMessage(plugin.getMessages().get("rank-updated", "player", Bukkit.getOfflinePlayer(targetUuid).getName(), "rank", nextRank.getDisplayName()));
            plugin.getMenuManager().openMemberManage(player, targetUuid);
        } else {
            player.sendMessage(plugin.getMessages().get("cannot-assign-higher-rank"));
        }
    }

    private void handleMemberDemote(Player player) {
        ActiveMenu active = plugin.getMenuManager().getOpenMenu(player).orElse(null);
        if (active == null || active.getTargetUuid() == null) return;
        UUID targetUuid = active.getTargetUuid();

        Optional<ClanMember> optTarget = plugin.getMemberService().getMember(targetUuid);
        if (optTarget.isEmpty()) return;

        ClanMember target = optTarget.get();
        List<ClanRank> ranks = new ArrayList<>(plugin.getRankService().allRanks());
        ranks.sort(Comparator.comparingInt(ClanRank::getPriority).reversed());

        ClanRank prevRank = null;
        for (ClanRank r : ranks) {
            ClanRank curRank = plugin.getRankService().getRank(target.getRankId()).orElse(null);
            if (curRank != null && r.getPriority() < curRank.getPriority()) {
                prevRank = r;
                break;
            }
        }

        if (prevRank == null) {
            player.sendMessage(plugin.getMessages().get("rank-lowest"));
            return;
        }

        MemberService.RankResult res = plugin.getMemberService().assignRank(player.getUniqueId(), targetUuid, prevRank.getId());
        if (res == MemberService.RankResult.OK) {
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
            player.sendMessage(plugin.getMessages().get("rank-updated", "player", Bukkit.getOfflinePlayer(targetUuid).getName(), "rank", prevRank.getDisplayName()));
            plugin.getMenuManager().openMemberManage(player, targetUuid);
        } else {
            player.sendMessage(plugin.getMessages().get("cannot-assign-higher-rank"));
        }
    }

    private void handleMemberKick(Player player) {
        ActiveMenu active = plugin.getMenuManager().getOpenMenu(player).orElse(null);
        if (active == null || active.getTargetUuid() == null) return;
        UUID targetUuid = active.getTargetUuid();
        OfflinePlayer op = Bukkit.getOfflinePlayer(targetUuid);
        String targetName = op.getName() != null ? op.getName() : "Unknown";

        String title = plugin.getMessages().get("gui-confirm-kick-title", "player", targetName);
        plugin.getMenuManager().openConfirm(player, "kick", title, () -> {
            MemberService.KickResult res = plugin.getMemberService().kick(player.getUniqueId(), targetUuid);
            if (res == MemberService.KickResult.OK) {
                player.sendMessage(plugin.getMessages().get("player-kicked", "player", targetName));
                plugin.getMenuManager().openMembersMenu(player, 0);
            } else if (res == MemberService.KickResult.CANNOT_KICK_LEADER) {
                player.sendMessage(plugin.getMessages().get("cannot-kick-leader"));
            } else if (res == MemberService.KickResult.RANK_TOO_HIGH) {
                player.sendMessage(plugin.getMessages().get("cannot-kick-higher-rank"));
            } else {
                player.sendMessage(plugin.getMessages().get("no-permission"));
            }
        });
    }

    private void handleMemberTransferLeader(Player player) {
        ActiveMenu active = plugin.getMenuManager().getOpenMenu(player).orElse(null);
        if (active == null || active.getTargetUuid() == null) return;
        UUID targetUuid = active.getTargetUuid();
        OfflinePlayer op = Bukkit.getOfflinePlayer(targetUuid);
        String targetName = op.getName() != null ? op.getName() : "Unknown";

        Clan clan = plugin.getClanService().findByPlayer(player.getUniqueId()).orElse(null);
        if (clan == null || !clan.getLeader().equals(player.getUniqueId())) {
            player.sendMessage(plugin.getMessages().get("no-permission"));
            return;
        }

        String title = plugin.getMessages().get("gui-confirm-transfer-title", "player", targetName);
        plugin.getMenuManager().openConfirm(player, "transfer", title, () -> {
            String leaderRank = plugin.getRankService().getLeaderRank().map(ClanRank::getId).orElse("leader");
            String defaultRank = plugin.getRankService().getDefaultRank().map(ClanRank::getId).orElse("member");

            // Demote old leader
            plugin.getMemberService().getMember(player.getUniqueId()).ifPresent(m -> {
                m.setRankId(defaultRank);
                plugin.getMemberService().getMemberRepo().updateRank(player.getUniqueId(), defaultRank);
            });
            // Promote new leader
            clan.setLeader(targetUuid);
            clan.setLeaderRankId(leaderRank);
            plugin.getMemberService().getMember(targetUuid).ifPresent(m -> {
                m.setRankId(leaderRank);
                plugin.getMemberService().getMemberRepo().updateRank(targetUuid, leaderRank);
            });

            plugin.getClanService().saveAsync(clan);
            player.sendMessage(plugin.getMessages().get("leader-transferred", "clan", clan.getName(), "player", targetName));
            if (op.isOnline() && op.getPlayer() != null) {
                op.getPlayer().sendMessage(plugin.getMessages().get("new-leader-notify", "clan", clan.getName()));
            }
            plugin.getMenuManager().openMainMenu(player);
        });
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getInventory().getHolder() instanceof MenuHolder) {
            if (event.getPlayer() instanceof Player player) {
                plugin.getMenuManager().onClose(player);
            }
        }
    }
}
