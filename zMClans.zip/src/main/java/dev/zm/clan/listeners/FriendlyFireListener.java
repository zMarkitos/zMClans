package dev.zm.clan.listeners;

import dev.zm.clan.clan.model.Clan;
import dev.zm.clan.zMClans;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles clan friendly fire prevention.
 */
public final class FriendlyFireListener implements Listener {

    private final zMClans plugin;
    private final Map<UUID, Long> lastWarning = new ConcurrentHashMap<>();

    public FriendlyFireListener(zMClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) {
            return;
        }

        Player attacker = resolveAttacker(event.getDamager());
        if (attacker == null || attacker.equals(victim)) {
            return;
        }

        Optional<Clan> attackerClan = plugin.getClanService().findByPlayer(attacker.getUniqueId());
        Optional<Clan> victimClan = plugin.getClanService().findByPlayer(victim.getUniqueId());

        if (attackerClan.isEmpty() || victimClan.isEmpty()) {
            return;
        }

        Clan clan = attackerClan.get();
        if (clan.getId().equals(victimClan.get().getId())) {
            if (!clan.isFriendlyFire()) {
                event.setCancelled(true);
                long now = System.currentTimeMillis();
                long last = lastWarning.getOrDefault(attacker.getUniqueId(), 0L);
                if (now - last > 2000L) {
                    attacker.sendMessage(plugin.getMessages().get("friendly-fire-blocked"));
                    lastWarning.put(attacker.getUniqueId(), now);
                }
            }
        }
    }

    private Player resolveAttacker(Entity damager) {
        if (damager instanceof Player player) {
            return player;
        }
        if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Player shooter) {
            return shooter;
        }
        return null;
    }
}
