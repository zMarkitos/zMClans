package dev.zm.clan.listeners;

import dev.zm.clan.clan.model.Clan;
import dev.zm.clan.config.ColorUtil;
import dev.zm.clan.member.model.ClanMember;
import dev.zm.clan.rank.model.ClanRank;
import dev.zm.clan.zMClans;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles clan chat toggling and message broadcasting.
 * Uses Paper's AsyncChatEvent (Adventure API) — compatible with Paper 1.20+.
 */
public final class ClanChatListener implements Listener {

    private final zMClans plugin;
    private final Set<UUID> chatToggledPlayers = ConcurrentHashMap.newKeySet();

    public ClanChatListener(zMClans plugin) {
        this.plugin = plugin;
    }

    public boolean toggleChat(UUID uuid) {
        if (chatToggledPlayers.contains(uuid)) {
            chatToggledPlayers.remove(uuid);
            return false;
        } else {
            chatToggledPlayers.add(uuid);
            return true;
        }
    }

    public boolean isInClanChat(UUID uuid) {
        return chatToggledPlayers.contains(uuid);
    }

    public void removePlayer(UUID uuid) {
        chatToggledPlayers.remove(uuid);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onPlayerChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        if (!isInClanChat(player.getUniqueId())) {
            return;
        }

        Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());
        if (optClan.isEmpty()) {
            // Player left clan but toggle was still on — clean up
            chatToggledPlayers.remove(player.getUniqueId());
            return;
        }

        // Extract plain text from Adventure component
        String message = PlainTextComponentSerializer.plainText().serialize(event.message());
        event.setCancelled(true);
        sendClanMessage(player, optClan.get(), message);
    }

    public void sendClanMessage(Player sender, Clan clan, String message) {
        String format = plugin.getConfigManager().getChatFormat();
        String rankId = clan.getMember(sender.getUniqueId()).map(ClanMember::getRankId).orElse("member");
        String rankName = plugin.getRankService().getRank(rankId)
                .map(ClanRank::getDisplayName).orElse(rankId);
        String prefix = plugin.getRankService().getRank(rankId).map(ClanRank::getPrefix).orElse("");

        String formatted = format
                .replace("{tag}", clan.getTag())
                .replace("{clan}", clan.getName())
                .replace("{rank_prefix}", prefix)
                .replace("{rank}", rankName)
                .replace("{player}", sender.getName())
                .replace("{message}", message);

        String colored = ColorUtil.colorize(formatted);

        for (UUID memberUuid : clan.getMemberIds()) {
            Player target = Bukkit.getPlayer(memberUuid);
            if (target != null && target.isOnline()) {
                target.sendMessage(colored);
            }
        }
    }
}
