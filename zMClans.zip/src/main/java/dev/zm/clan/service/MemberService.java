package dev.zm.clan.service;

import dev.zm.clan.clan.model.Clan;
import dev.zm.clan.member.model.ClanMember;
import dev.zm.clan.member.repository.MemberRepository;
import dev.zm.clan.rank.model.ClanRank;
import dev.zm.clan.zMClans;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages member lifecycle: joining, leaving, kicking, rank changes.
 * Maintains a player-to-member cache for O(1) member lookups.
 */
public final class MemberService {

    private final zMClans plugin;
    private final MemberRepository memberRepo;

    /** player UUID → ClanMember (all members of all clans) */
    private final Map<UUID, ClanMember> memberCache = new ConcurrentHashMap<>();

    public enum KickResult { OK, NO_PERMISSION, CANNOT_KICK_LEADER, RANK_TOO_HIGH, NOT_IN_CLAN }
    public enum RankResult { OK, RANK_NOT_FOUND, NO_PERMISSION, SAME_RANK, CANNOT_ASSIGN_HIGHER }

    public MemberService(zMClans plugin) {
        this.plugin     = plugin;
        this.memberRepo = new MemberRepository(plugin.getDatabaseManager(), plugin.getLogger());
    }

    // ---- Load all ------------------------------------------------

    /** Loads all members from database into the cache on startup. */
    public void loadAll() {
        memberCache.clear();
        for (Clan clan : plugin.getClanService().allClans()) {
            List<ClanMember> members = memberRepo.findByClan(clan.getId());
            for (ClanMember m : members) {
                memberCache.put(m.getPlayerUUID(), m);
                clan.addMember(m.getPlayerUUID());
                plugin.getClanService().indexPlayer(m.getPlayerUUID(), clan.getId());
            }
        }
    }

    /** Loads a single member into the cache (used when checking or join). */
    public Optional<ClanMember> loadPlayer(UUID playerUUID) {
        Optional<ClanMember> opt = memberRepo.findByPlayer(playerUUID);
        opt.ifPresent(m -> memberCache.put(playerUUID, m));
        return opt;
    }

    public void registerMember(ClanMember member) {
        if (member != null) {
            memberCache.put(member.getPlayerUUID(), member);
        }
    }

    public void unloadPlayer(UUID playerUUID) {
        // Keep in cache so offline members remain manageable and visible in GUI
    }

    // ---- Join ----------------------------------------------------

    public boolean joinClan(UUID playerUUID, UUID clanId, String defaultRankId) {
        ClanMember m = new ClanMember(playerUUID, clanId, defaultRankId, Instant.now());
        memberCache.put(playerUUID, m);

        // Update clan object in memory
        plugin.getClanService().findById(clanId).ifPresent(c -> c.addMember(playerUUID));
        plugin.getClanService().indexPlayer(playerUUID, clanId);

        CompletableFuture.runAsync(() -> memberRepo.insert(m));
        return true;
    }

    // ---- Leave ---------------------------------------------------

    public boolean leaveClan(UUID playerUUID) {
        if (playerUUID == null) return false;
        ClanMember current = getMember(playerUUID).orElse(null);
        if (current == null) return false;

        // The clan owner must transfer leadership or disband the clan; never allow
        // leaving through commands, GUIs, or any other caller.
        Clan clan = plugin.getClanService().findById(current.getClanId()).orElse(null);
        if (clan != null && clan.getLeader().equals(playerUUID)) return false;
        if (plugin.getRankService().getRank(current.getRankId()).map(ClanRank::isLeader).orElse(false)) return false;
        return removeMemberInternal(playerUUID, current);
    }

    /** Internal removal path reserved for clan disbanding after ownership checks. */
    public boolean removeMemberForDisband(UUID playerUUID) {
        if (playerUUID == null) return false;
        ClanMember current = memberCache.get(playerUUID);
        if (current == null) current = memberRepo.findByPlayer(playerUUID).orElse(null);
        return current != null && removeMemberInternal(playerUUID, current);
    }

    private boolean removeMemberInternal(UUID playerUUID, ClanMember member) {
        memberCache.remove(playerUUID);
        plugin.getClanService().findById(member.getClanId()).ifPresent(c -> c.removeMember(playerUUID));
        plugin.getClanService().unindexPlayer(playerUUID);
        CompletableFuture.runAsync(() -> memberRepo.delete(playerUUID));
        return true;
    }

    public boolean leave(org.bukkit.entity.Player player) {
        return leaveClan(player.getUniqueId());
    }

    // ---- Kick ----------------------------------------------------

    public KickResult kick(UUID actorUUID, UUID targetUUID) {
        ClanMember actor  = getMember(actorUUID).orElse(null);
        ClanMember target = getMember(targetUUID).orElse(null);

        if (actor == null || target == null || !actor.getClanId().equals(target.getClanId()))
            return KickResult.NOT_IN_CLAN;

        ClanRank actorRank  = plugin.getRankService().getRank(actor.getRankId()).orElse(null);
        ClanRank targetRank = plugin.getRankService().getRank(target.getRankId()).orElse(null);

        if (actorRank == null || !actorRank.hasPermission(ClanRank.Permission.KICK))
            return KickResult.NO_PERMISSION;
        if (targetRank != null && targetRank.isLeader())
            return KickResult.CANNOT_KICK_LEADER;
        if (targetRank != null && targetRank.getPriority() >= actorRank.getPriority())
            return KickResult.RANK_TOO_HIGH;

        leaveClan(targetUUID);
        return KickResult.OK;
    }

    // ---- Rank change ---------------------------------------------

    public RankResult assignRank(UUID actorUUID, UUID targetUUID, String newRankId) {
        ClanMember actor  = getMember(actorUUID).orElse(null);
        ClanMember target = getMember(targetUUID).orElse(null);
        if (actor == null || target == null) return RankResult.NO_PERMISSION;

        ClanRank newRank   = plugin.getRankService().getRank(newRankId).orElse(null);
        ClanRank actorRank = plugin.getRankService().getRank(actor.getRankId()).orElse(null);

        if (newRank == null) return RankResult.RANK_NOT_FOUND;
        if (actorRank == null || !actorRank.hasPermission(ClanRank.Permission.PROMOTE))
            return RankResult.NO_PERMISSION;
        if (newRank.getPriority() >= actorRank.getPriority())
            return RankResult.CANNOT_ASSIGN_HIGHER;
        if (target.getRankId().equalsIgnoreCase(newRankId))
            return RankResult.SAME_RANK;

        target.setRankId(newRankId);
        CompletableFuture.runAsync(() -> memberRepo.updateRank(targetUUID, newRankId));
        return RankResult.OK;
    }

    // ---- Queries -------------------------------------------------

    public Optional<ClanMember> getMember(UUID uuid) {
        if (uuid == null) return Optional.empty();
        ClanMember m = memberCache.get(uuid);
        if (m != null) return Optional.of(m);
        // Fallback to database
        Optional<ClanMember> opt = memberRepo.findByPlayer(uuid);
        opt.ifPresent(cm -> memberCache.put(uuid, cm));
        return opt;
    }

    public boolean isLoaded(UUID uuid) {
        return memberCache.containsKey(uuid);
    }

    /** Returns all members of a specific clan. */
    public List<ClanMember> getMembersOfClan(UUID clanId) {
        if (clanId == null) return Collections.emptyList();
        List<ClanMember> fromCache = memberCache.values().stream()
                .filter(m -> clanId.equals(m.getClanId()))
                .toList();
        if (!fromCache.isEmpty()) {
            return fromCache;
        }
        // Fallback to DB
        List<ClanMember> fromDb = memberRepo.findByClan(clanId);
        for (ClanMember cm : fromDb) {
            memberCache.put(cm.getPlayerUUID(), cm);
        }
        return fromDb;
    }

    public boolean hasPermission(UUID playerUUID, ClanRank.Permission perm) {
        if (playerUUID == null || perm == null) return false;
        ClanMember m = getMember(playerUUID).orElse(null);
        if (m == null) return false;
        return plugin.getRankService().getRank(m.getRankId())
                .map(r -> r.hasPermission(perm))
                .orElse(false);
    }

    public MemberRepository getMemberRepo() {
        return memberRepo;
    }
}
