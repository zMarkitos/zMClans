package dev.zm.clan.service;

import dev.zm.clan.clan.model.Clan;
import dev.zm.clan.clan.model.ClanHome;
import dev.zm.clan.rank.model.ClanRank;
import dev.zm.clan.zMClans;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages /clan home and /clan sethome with cooldown and warmup support.
 */
public final class HomeService {

    private final zMClans plugin;

    /** player UUID → unix second of last teleport */
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();

    /** player UUID → warmup runnable (so we can cancel on move or duplicate request) */
    private final Map<UUID, BukkitRunnable> warmups = new ConcurrentHashMap<>();

    public enum SetHomeResult { OK, NO_PERMISSION, NO_CLAN }
    public enum TeleportResult { OK, NO_HOME, NO_CLAN, WORLD_UNLOADED, COOLDOWN, NO_PERMISSION }

    public HomeService(zMClans plugin) {
        this.plugin = plugin;
    }

    // ---- Set home ------------------------------------------------

    public SetHomeResult setHome(Player player) {
        if (!plugin.getMemberService().hasPermission(player.getUniqueId(), ClanRank.Permission.SET_HOME))
            return SetHomeResult.NO_PERMISSION;

        Clan clan = plugin.getClanService().findByPlayer(player.getUniqueId()).orElse(null);
        if (clan == null) return SetHomeResult.NO_CLAN;

        clan.setHome(new ClanHome(player.getLocation()));
        // Persist immediately async
        plugin.getClanService().saveAsync(clan);
        return SetHomeResult.OK;
    }

    // ---- Teleport to home ----------------------------------------

    public TeleportResult teleport(Player player) {
        if (!player.hasPermission("zmclans.clan.home")) return TeleportResult.NO_PERMISSION;

        Clan clan = plugin.getClanService().findByPlayer(player.getUniqueId()).orElse(null);
        if (clan == null) return TeleportResult.NO_CLAN;

        // Check rank permission USE_HOME
        if (!plugin.getMemberService().hasPermission(player.getUniqueId(), ClanRank.Permission.USE_HOME))
            return TeleportResult.NO_PERMISSION;

        ClanHome home = clan.getHome();
        if (home == null) return TeleportResult.NO_HOME;
        if (!home.isWorldLoaded()) return TeleportResult.WORLD_UNLOADED;

        // Cooldown check (bypass perm)
        int cooldownSecs = plugin.getConfigManager().getHomeCooldown();
        if (cooldownSecs > 0 && !player.hasPermission("zmclans.clan.bypass.cooldown")) {
            long last = cooldowns.getOrDefault(player.getUniqueId(), 0L);
            long remaining = cooldownSecs - (System.currentTimeMillis() / 1000 - last);
            if (remaining > 0) {
                player.sendMessage(plugin.getMessages().get("home-cooldown", "time", String.valueOf(remaining)));
                return TeleportResult.COOLDOWN;
            }
        }

        int warmupSecs = plugin.getConfigManager().getHomeWarmup();
        Location destination = home.toBukkitLocation();

        if (warmupSecs <= 0) {
            doTeleport(player, destination);
            return TeleportResult.OK;
        }

        // Cancel any existing warmup for this player to prevent multiple concurrent tasks
        cancelWarmup(player.getUniqueId());

        // Warmup phase
        Location startLoc = player.getLocation().clone();
        player.sendMessage(plugin.getMessages().get("home-teleporting", "time", String.valueOf(warmupSecs)));

        BukkitRunnable task = new BukkitRunnable() {
            @Override
            public void run() {
                warmups.remove(player.getUniqueId());
                if (!player.isOnline()) {
                    return;
                }
                doTeleport(player, destination);
            }
        };

        warmups.put(player.getUniqueId(), task);
        task.runTaskLater(plugin, 20L * warmupSecs);
        return TeleportResult.OK;
    }

    /**
     * Called when a player moves block. If cancel-on-move is enabled and the player
     * is currently in a warmup, cancels it immediately with a message.
     */
    public void checkMoveCancel(Player player) {
        if (!plugin.getConfigManager().isCancelOnMove() || player == null) return;
        UUID uuid = player.getUniqueId();
        BukkitRunnable r = warmups.remove(uuid);
        if (r != null) {
            try {
                r.cancel();
            } catch (IllegalStateException ignored) {}
            player.sendMessage(plugin.getMessages().get("home-cancelled"));
        }
    }

    private void doTeleport(Player player, Location destination) {
        if (player.isOnline() && destination != null) {
            player.teleport(destination);
            player.sendMessage(plugin.getMessages().get("home-teleported"));
            cooldowns.put(player.getUniqueId(), System.currentTimeMillis() / 1000);
        }
    }

    /** Cancel warmup if player disconnects or triggers a new teleport. */
    public void cancelWarmup(UUID uuid) {
        if (uuid == null) return;
        BukkitRunnable r = warmups.remove(uuid);
        if (r != null) {
            try {
                r.cancel();
            } catch (IllegalStateException ignored) {}
        }
    }

    private boolean isSameBlock(Location a, Location b) {
        if (a == null || b == null) return false;
        if (a.getWorld() != b.getWorld()) return false;
        return a.getBlockX() == b.getBlockX()
                && a.getBlockY() == b.getBlockY()
                && a.getBlockZ() == b.getBlockZ();
    }
}
