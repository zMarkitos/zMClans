package dev.zm.clan.service;

import dev.zm.clan.clan.model.Clan;
import dev.zm.clan.clan.repository.ClanRepository;
import dev.zm.clan.config.ColorUtil;
import dev.zm.clan.member.model.ClanMember;
import dev.zm.clan.rank.model.ClanRank;
import dev.zm.clan.zMClans;
import org.bukkit.entity.Player;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Core business logic for clan lifecycle: create, disband, info, search.
 * All DB writes are executed asynchronously during runtime; in-memory cache
 * is updated immediately so reads are always instant on the main thread.
 * Synchronous save is provided for server shutdown.
 */
public final class ClanService {

    private final zMClans plugin;
    private final ClanRepository clanRepo;

    // ---- In-memory caches ----------------------------------------
    /** clan ID → Clan */
    private final Map<UUID, Clan> clanById = new ConcurrentHashMap<>();
    /** lowercase name → clan ID */
    private final Map<String, UUID> nameIndex = new ConcurrentHashMap<>();
    /** lowercase clean tag  → clan ID */
    private final Map<String, UUID> tagIndex = new ConcurrentHashMap<>();
    /** player UUID → clan ID */
    private final Map<UUID, UUID> playerIndex = new ConcurrentHashMap<>();

    public ClanService(zMClans plugin) {
        this.plugin    = plugin;
        this.clanRepo  = new ClanRepository(plugin.getDatabaseManager(), plugin.getLogger());
        loadAll();
    }

    // ---- Startup load -------------------------------------------

    public void loadAll() {
        clanById.clear();
        nameIndex.clear();
        tagIndex.clear();
        playerIndex.clear();

        List<Clan> all = clanRepo.findAll();
        for (Clan c : all) {
            clanById.put(c.getId(), c);
            nameIndex.put(c.getName().toLowerCase(Locale.ROOT), c.getId());
            tagIndex.put(ColorUtil.strip(c.getTag()).toLowerCase(Locale.ROOT), c.getId());
        }
    }

    // ---- Create --------------------------------------------------

    public enum CreateResult { OK, NAME_TAKEN, TAG_TAKEN, NAME_INVALID, TAG_INVALID, NO_MONEY, ALREADY_IN_CLAN }

    public CreateResult create(Player player, String name, String tag) {
        if (playerIndex.containsKey(player.getUniqueId())) return CreateResult.ALREADY_IN_CLAN;

        var cfg = plugin.getConfigManager();
        if (!name.matches(cfg.getNamePattern()) || name.length() < cfg.getNameMinLength() || name.length() > cfg.getNameMaxLength())
            return CreateResult.NAME_INVALID;
        if (nameIndex.containsKey(name.toLowerCase(Locale.ROOT))) return CreateResult.NAME_TAKEN;

        String storedTag;
        String indexedTag;

        if (tag == null || tag.isBlank()) {
            storedTag = "";
            indexedTag = name.toLowerCase(Locale.ROOT);
        } else {
            storedTag = ColorUtil.colorize(tag);
            String cleanTag = ColorUtil.strip(storedTag);
            if (!cleanTag.matches(cfg.getTagPattern()) || cleanTag.length() < cfg.getTagMinLength() || cleanTag.length() > cfg.getTagMaxLength())
                return CreateResult.TAG_INVALID;
            indexedTag = cleanTag.toLowerCase(Locale.ROOT);
        }

        if (tagIndex.containsKey(indexedTag)) return CreateResult.TAG_TAKEN;

        // Economy check
        double cost = cfg.getCreationCost();
        if (cost > 0 && !player.hasPermission("zmclans.clan.bypass.cost")) {
            var vault = plugin.getHookManager().getVaultHook();
            if (vault == null || !vault.has(player, cost)) return CreateResult.NO_MONEY;
            vault.withdraw(player, cost);
        }

        // Find the leader rank
        String leaderRankId = plugin.getRankService().getLeaderRank()
                .map(ClanRank::getId).orElse("leader");

        Clan clan = Clan.builder()
                .name(name)
                .tag(storedTag)
                .leader(player.getUniqueId())
                .leaderRankId(leaderRankId)
                .createdAt(Instant.now())
                .build();

        ClanMember leaderMember = new ClanMember(
                player.getUniqueId(), clan.getId(), leaderRankId, Instant.now());

        // Update cache first
        clanById.put(clan.getId(), clan);
        nameIndex.put(name.toLowerCase(Locale.ROOT), clan.getId());
        tagIndex.put(indexedTag, clan.getId());
        clan.addMember(player.getUniqueId());
        playerIndex.put(player.getUniqueId(), clan.getId());

        // Register member in MemberService immediately!
        if (plugin.getMemberService() != null) {
            plugin.getMemberService().registerMember(leaderMember);
        }

        // Persist async
        CompletableFuture.runAsync(() -> {
            clanRepo.insert(clan);
            if (plugin.getMemberService() != null) {
                plugin.getMemberService().getMemberRepo().insert(leaderMember);
            }
        });

        return CreateResult.OK;
    }

    // ---- Modify Tag ----------------------------------------------

    public enum ModTagResult {
        OK,
        TAG_INVALID,
        TAG_TAKEN,
        NO_CLAN,
        NO_PERMISSION
    }

    public ModTagResult modifyTag(Player player, String rawTag) {
        if (!player.hasPermission("zmclans.clan.modtag")) {
            return ModTagResult.NO_PERMISSION;
        }

        Clan clan = findByPlayer(player.getUniqueId()).orElse(null);
        if (clan == null) return ModTagResult.NO_CLAN;

        if (!clan.getLeader().equals(player.getUniqueId())
                && !plugin.getMemberService().hasPermission(player.getUniqueId(), ClanRank.Permission.MODTAG)) {
            return ModTagResult.NO_PERMISSION;
        }

        var cfg = plugin.getConfigManager();
        String formattedTag = ColorUtil.colorize(rawTag);
        String cleanTag = ColorUtil.strip(formattedTag);

        if (cleanTag.isEmpty()
                || cleanTag.length() < cfg.getTagMinLength()
                || cleanTag.length() > cfg.getTagMaxLength()
                || !cleanTag.matches(cfg.getTagPattern())) {
            return ModTagResult.TAG_INVALID;
        }

        String cleanLower = cleanTag.toLowerCase(Locale.ROOT);
        UUID existingClanId = tagIndex.get(cleanLower);
        if (existingClanId != null && !existingClanId.equals(clan.getId())) {
            return ModTagResult.TAG_TAKEN;
        }

        // Remove previous clean tag from index
        String oldClean = ColorUtil.strip(clan.getTag()).toLowerCase(Locale.ROOT);
        tagIndex.remove(oldClean);

        // Update clan tag with formatted tag (MiniMessage/hex converted to legacy section)
        clan.setTag(formattedTag);
        tagIndex.put(cleanLower, clan.getId());

        saveAsync(clan);
        return ModTagResult.OK;
    }

    // ---- Disband -------------------------------------------------

    public boolean disband(UUID clanId) {
        Clan clan = clanById.remove(clanId);
        if (clan == null) return false;

        nameIndex.remove(clan.getName().toLowerCase(Locale.ROOT));
        tagIndex.remove(ColorUtil.strip(clan.getTag()).toLowerCase(Locale.ROOT));

        List<UUID> members = new ArrayList<>(clan.getMemberIds());
        for (UUID mUuid : members) {
            playerIndex.remove(mUuid);
            if (plugin.getMemberService() != null) {
                plugin.getMemberService().removeMemberForDisband(mUuid);
            }
        }

        CompletableFuture.runAsync(() -> {
            if (plugin.getMemberService() != null) {
                plugin.getMemberService().getMemberRepo().deleteByClan(clanId);
            }
            clanRepo.delete(clanId);
        });

        return true;
    }

    // ---- Persist -------------------------------------------------

    public void saveAll() {
        clanById.values().forEach(c -> CompletableFuture.runAsync(() -> clanRepo.update(c)));
    }

    public void saveAllSync() {
        for (Clan c : clanById.values()) {
            clanRepo.update(c);
        }
    }

    public void saveAsync(Clan clan) {
        if (clan != null) {
            CompletableFuture.runAsync(() -> clanRepo.update(clan));
        }
    }

    // ---- Queries -------------------------------------------------

    public Optional<Clan> findById(UUID id) {
        if (id == null) return Optional.empty();
        return Optional.ofNullable(clanById.get(id));
    }

    public Optional<Clan> findByName(String name) {
        if (name == null) return Optional.empty();
        UUID id = nameIndex.get(name.toLowerCase(Locale.ROOT));
        return id == null ? Optional.empty() : findById(id);
    }

    public Optional<Clan> findByTag(String tag) {
        if (tag == null) return Optional.empty();
        UUID id = tagIndex.get(ColorUtil.strip(tag).toLowerCase(Locale.ROOT));
        return id == null ? Optional.empty() : findById(id);
    }

    public Optional<Clan> findByPlayer(UUID uuid) {
        if (uuid == null) return Optional.empty();
        UUID id = playerIndex.get(uuid);
        return id == null ? Optional.empty() : findById(id);
    }

    public boolean isInClan(UUID uuid)     { return uuid != null && playerIndex.containsKey(uuid); }
    public boolean nameExists(String name) { return name != null && nameIndex.containsKey(name.toLowerCase(Locale.ROOT)); }
    public boolean tagExists(String tag)   { return tag != null && tagIndex.containsKey(ColorUtil.strip(tag).toLowerCase(Locale.ROOT)); }

    public List<Clan> allClans() {
        return new ArrayList<>(clanById.values());
    }

    public List<Clan> findAll() {
        List<Clan> list = allClans();
        String sortBy = plugin.getConfigManager() != null ? plugin.getConfigManager().getLeaderboardSortBy() : "MEMBERS";
        if ("POINTS".equalsIgnoreCase(sortBy)) {
            list.sort(Comparator.comparingLong(Clan::getPoints).reversed());
        } else {
            list.sort(Comparator.comparingInt(Clan::getMemberCount).reversed());
        }
        return list;
    }

    // ---- Player index management ---------------------------------

    public void indexPlayer(UUID player, UUID clan) {
        if (player != null && clan != null) {
            playerIndex.put(player, clan);
        }
    }

    public void unindexPlayer(UUID player) {
        if (player != null) {
            playerIndex.remove(player);
        }
    }
}
