package dev.zm.clan.hook;

import dev.zm.clan.clan.model.Clan;
import dev.zm.clan.config.ColorUtil;
import dev.zm.clan.member.model.ClanMember;
import dev.zm.clan.rank.model.ClanRank;
import dev.zm.clan.zMClans;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.clip.placeholderapi.expansion.Relational;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * PlaceholderAPI expansion for zMClans.
 * Supports %zmclans_...% and compatibility alias %uclans_...%.
 * Fully implements standard, relational, and dynamic placeholders.
 */
public final class ClanPlaceholderExpansion extends PlaceholderExpansion implements Relational {

    private final zMClans plugin;
    private final String identifier;

    public ClanPlaceholderExpansion(zMClans plugin) {
        this(plugin, "zmclans");
    }

    public ClanPlaceholderExpansion(zMClans plugin, String identifier) {
        this.plugin = plugin;
        this.identifier = identifier;
    }

    @Override
    public @NotNull String getIdentifier() {
        return identifier;
    }

    @Override
    public @NotNull String getAuthor() {
        return "zMarkitos_";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public @Nullable String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null)
            return "";

        String p = params.toLowerCase(Locale.ROOT);

        // Dynamic leaderboard: top:<N>, top_points:<N>, top_tag:<N>
        if (p.startsWith("top:") || p.startsWith("top_name:")) {
            int rank = parseRankSuffix(p);
            return getTopClan(rank).map(Clan::getName).orElse("");
        }
        if (p.startsWith("top_tag:")) {
            int rank = parseRankSuffix(p);
            return getTopClan(rank).map(Clan::getTag).orElse("");
        }
        if (p.startsWith("top_points:")) {
            int rank = parseRankSuffix(p);
            return getTopClan(rank).map(c -> String.valueOf(c.getPoints())).orElse("0");
        }
        if (p.startsWith("top_members:")) {
            int rank = parseRankSuffix(p);
            return getTopClan(rank).map(c -> String.valueOf(c.getMemberCount())).orElse("0");
        }
        if (p.startsWith("top_leader:")) {
            int rank = parseRankSuffix(p);
            return getTopClan(rank).map(c -> {
                OfflinePlayer op = Bukkit.getOfflinePlayer(c.getLeader());
                return op.getName() != null ? op.getName() : "Unknown";
            }).orElse("");
        }

        // Search clan of another player: search_player_clan:<name>
        if (p.startsWith("search_player_clan:")) {
            String targetName = params.substring("search_player_clan:".length()).trim();
            OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
            return plugin.getClanService().findByPlayer(target.getUniqueId()).map(Clan::getName).orElse("");
        }

        Optional<Clan> optClan = plugin.getClanService().findByPlayer(player.getUniqueId());

        return switch (p) {
            // ---- Presence & Identification ----
            case "hasclan", "has_clan", "in_clan" -> optClan.isPresent() ? "true" : "false";
            case "hasclan_formated", "hasclan_formatted" ->
                optClan.map(c -> c.hasCustomTag() ? c.getTag() : c.getName()).orElse("");
            case "hasclan_formated_nocolor" -> optClan.map(c -> ColorUtil.strip(c.getTag())).orElse("");
            case "clan", "clan_name", "name" -> optClan.map(Clan::getName).orElse("");
            case "clanid", "clan_id", "id", "uuid" -> optClan.map(c -> c.getId().toString()).orElse("");

            // ---- Tag & Modtag (Crucial: falls back to name if no custom modtag) ----
            case "modtag" -> optClan.map(c -> c.hasCustomTag() ? c.getTag() : c.getName()).orElse("");
            case "tag" -> optClan.map(Clan::getTag).orElse("");
            case "tag_color", "tag_formated", "tag_formatted" -> optClan.map(Clan::getTag).orElse("");
            case "tag_nocolor", "tag_formated_nocolor", "tag_stripped" ->
                optClan.map(c -> ColorUtil.strip(c.getTag())).orElse("");

            // ---- Leader ----
            case "leader", "leader_name" -> optClan.map(c -> {
                OfflinePlayer leader = Bukkit.getOfflinePlayer(c.getLeader());
                return leader.getName() != null ? leader.getName() : "Unknown";
            }).orElse("");
            case "leader_uuid" -> optClan.map(c -> c.getLeader().toString()).orElse("");
            case "is_leader" ->
                optClan.filter(c -> c.getLeader().equals(player.getUniqueId())).isPresent() ? "true" : "false";
            case "leader_formated" -> optClan.map(c -> {
                OfflinePlayer leader = Bukkit.getOfflinePlayer(c.getLeader());
                String lName = leader.getName() != null ? leader.getName() : "Unknown";
                return ColorUtil.colorize("&#55FFAA" + lName);
            }).orElse("");

            // ---- Members & Limits ----
            case "members", "clan_members", "count_members", "member_count" ->
                optClan.map(c -> String.valueOf(c.getMemberCount())).orElse("0");
            case "onlinemembers", "clan_onlinemembers", "count_onlinemembers", "online_members" -> optClan.map(c -> {
                long online = c.getMemberIds().stream()
                        .map(Bukkit::getPlayer)
                        .filter(Objects::nonNull)
                        .filter(Player::isOnline)
                        .count();
                return String.valueOf(online);
            }).orElse("0");
            case "slots", "slots_total", "max_members", "limit_members" ->
                String.valueOf(plugin.getConfigManager().getMaxMembers());

            // ---- Points & Leaderboard ----
            case "points", "clan_points" -> optClan.map(c -> String.format("%,d", c.getPoints())).orElse("0");
            case "points_unformated", "points_raw" -> optClan.map(c -> String.valueOf(c.getPoints())).orElse("0");
            case "current_position", "position", "top" -> optClan.map(c -> {
                List<Clan> all = plugin.getClanService().findAll();
                int pos = all.indexOf(c);
                return pos >= 0 ? String.valueOf(pos + 1) : "0";
            }).orElse("0");

            // ---- Description ----
            case "desc", "description", "desc_color" -> optClan.map(Clan::getDescription).orElse("");
            case "desc_nocolor" -> optClan.map(c -> ColorUtil.strip(c.getDescription())).orElse("");

            // ---- Settings ----
            case "is_ff", "global_ff", "friendly_fire" ->
                optClan.map(c -> String.valueOf(c.isFriendlyFire())).orElse("false");
            case "is_ff_formated", "global_ff_formated", "friendly_fire_formatted" ->
                optClan.map(c -> c.isFriendlyFire() ? "ON" : "OFF").orElse("OFF");
            case "isopen", "open_invites", "open_invitations" ->
                optClan.map(c -> String.valueOf(c.isOpenInvitations())).orElse("false");
            case "isopen_formated", "open_invites_formatted" ->
                optClan.map(c -> c.isOpenInvitations() ? "ON" : "OFF").orElse("OFF");
            case "chat_active" -> String.valueOf(plugin.getClanChatListener() != null
                    && plugin.getClanChatListener().isInClanChat(player.getUniqueId()));
            case "chat_active_formatted" -> (plugin.getClanChatListener() != null
                    && plugin.getClanChatListener().isInClanChat(player.getUniqueId())) ? "ON" : "OFF";

            // ---- Home ----
            case "hashome", "has_home" -> optClan.map(c -> String.valueOf(c.getHome() != null)).orElse("false");
            case "home", "home_location" -> optClan.map(c -> c.getHome() != null
                    ? (c.getHome().getWorldName() + " (" + (int) c.getHome().getX() + ", " + (int) c.getHome().getY()
                            + ", " + (int) c.getHome().getZ() + ")")
                    : "Not set").orElse("Not set");
            case "home_world" -> optClan.map(c -> c.getHome() != null ? c.getHome().getWorldName() : "").orElse("");
            case "home_x" ->
                optClan.map(c -> c.getHome() != null ? String.valueOf((int) c.getHome().getX()) : "").orElse("");
            case "home_y" ->
                optClan.map(c -> c.getHome() != null ? String.valueOf((int) c.getHome().getY()) : "").orElse("");
            case "home_z" ->
                optClan.map(c -> c.getHome() != null ? String.valueOf((int) c.getHome().getZ()) : "").orElse("");

            // ---- Dates ----
            case "creation_date", "creation_date_formated", "created_at" -> optClan.map(c -> {
                String d = c.getCreatedAt().toString();
                return d.length() >= 10 ? d.substring(0, 10) : d;
            }).orElse("");
            case "creation_hours", "created_timestamp" ->
                optClan.map(c -> String.valueOf(c.getCreatedAt().getEpochSecond())).orElse("0");

            // ---- Player Role / Rank ----
            case "player", "player_name" -> player.getName() != null ? player.getName() : "";
            case "player_role", "player_role_name", "role", "rank" ->
                plugin.getMemberService().getMember(player.getUniqueId())
                        .map(ClanMember::getRankId).orElse("");
            case "player_role_formated", "role_formated",
                    "rank_formated" ->
                plugin.getMemberService().getMember(player.getUniqueId())
                        .flatMap(m -> plugin.getRankService().getRank(m.getRankId()))
                        .map(r -> ColorUtil.colorize(r.getColor() + r.getDisplayName())).orElse("");
            case "player_role_prefix", "role_prefix",
                    "rank_prefix" ->
                plugin.getMemberService().getMember(player.getUniqueId())
                        .flatMap(m -> plugin.getRankService().getRank(m.getRankId()))
                        .map(r -> ColorUtil.colorize(r.getPrefix())).orElse("");
            case "player_joindate", "player_joindate_formated" ->
                plugin.getMemberService().getMember(player.getUniqueId())
                        .map(m -> {
                            String jd = m.getJoinedAt().toString();
                            return jd.length() >= 10 ? jd.substring(0, 10) : jd;
                        }).orElse("");
            case "player_permissions_amount" -> plugin.getMemberService().getMember(player.getUniqueId())
                    .flatMap(m -> plugin.getRankService().getRank(m.getRankId()))
                    .map(r -> String
                            .valueOf(Arrays.stream(ClanRank.Permission.values()).filter(r::hasPermission).count()))
                    .orElse("0");

            // ---- Compatibility Placeholders ----
            case "banner_material" -> "SHIELD";
            case "hasbanner", "hasbanner_formated" -> "true";
            case "money_currency", "bank_balance" -> optClan.map(c -> String.valueOf(c.getPoints())).orElse("0");
            case "bank_balance_formated" -> optClan.map(c -> String.format("%,d", c.getPoints())).orElse("0");
            case "kdr", "clan_kdr", "player_kdr" -> "0.0";
            case "kills", "clan_kills", "player_kills" -> "0";
            case "deaths", "clan_deaths", "player_deaths" -> "0";
            case "souls", "clan_souls" -> "0";
            case "level" -> "1";
            case "verified", "verified_tag", "verified_raw" -> "true";

            default -> null;
        };
    }

    // ---- Relational Placeholders (%rel_zmclans_...% / %rel_uclans_...%) ----

    @Override
    public @Nullable String onPlaceholderRequest(Player one, Player two, String identifier) {
        if (one == null || two == null)
            return "";

        Optional<Clan> clanOne = plugin.getClanService().findByPlayer(one.getUniqueId());
        Optional<Clan> clanTwo = plugin.getClanService().findByPlayer(two.getUniqueId());

        boolean sameClan = clanOne.isPresent() && clanTwo.isPresent()
                && clanOne.get().getId().equals(clanTwo.get().getId());

        String id = identifier.toLowerCase(Locale.ROOT);
        return switch (id) {
            case "relboolean_member" -> sameClan ? "true" : "false";
            case "relboolean_ally" -> sameClan ? "true" : "false";
            case "relboolean_rival" -> "false";
            case "relcolor" -> sameClan ? "&a" : "&c";
            case "reltext" -> sameClan ? "Member" : "";
            case "reltext_coloured" -> sameClan ? ColorUtil.colorize("&aMember") : "";
            default -> null;
        };
    }

    private Optional<Clan> getTopClan(int rank1Indexed) {
        if (rank1Indexed <= 0)
            return Optional.empty();
        List<Clan> all = plugin.getClanService().findAll();
        int index = rank1Indexed - 1;
        if (index >= 0 && index < all.size()) {
            return Optional.of(all.get(index));
        }
        return Optional.empty();
    }

    private int parseRankSuffix(String param) {
        int idx = param.lastIndexOf(':');
        if (idx >= 0 && idx + 1 < param.length()) {
            try {
                return Integer.parseInt(param.substring(idx + 1).trim());
            } catch (NumberFormatException ignored) {
            }
        }
        return 1;
    }
}
