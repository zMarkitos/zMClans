package dev.zm.clan;

import dev.zm.clan.bootstrap.PluginBootstrap;
import dev.zm.clan.config.ConfigManager;
import dev.zm.clan.config.Messages;
import dev.zm.clan.hook.HookManager;
import dev.zm.clan.menu.MenuManager;
import dev.zm.clan.service.ClanService;
import dev.zm.clan.service.HomeService;
import dev.zm.clan.service.InviteService;
import dev.zm.clan.service.MemberService;
import dev.zm.clan.service.RankService;
import dev.zm.clan.storage.DatabaseManager;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * zMClans — Main plugin class.
 * Delegates all initialization to {@link PluginBootstrap}.
 */
public final class zMClans extends JavaPlugin {

    private static zMClans instance;

    // Core managers (filled during bootstrap)
    private ConfigManager configManager;
    private Messages messages;
    private DatabaseManager databaseManager;
    private ClanService clanService;
    private MemberService memberService;
    private RankService rankService;
    private InviteService inviteService;
    private HomeService homeService;
    private MenuManager menuManager;
    private HookManager hookManager;
    private dev.zm.clan.listeners.ClanChatListener clanChatListener;

    @Override
    public void onEnable() {
        instance = this;
        new PluginBootstrap(this).boot();
    }

    @Override
    public void onDisable() {
        if (clanService != null) {
            clanService.saveAllSync();
        }
        if (databaseManager != null) {
            databaseManager.shutdown();
        }
        getLogger().info("zMClans disabled. Goodbye!");
    }

    // ----------------------------------------------------------------
    // Singleton accessor
    // ----------------------------------------------------------------
    public static zMClans get() {
        return instance;
    }

    // ----------------------------------------------------------------
    // Getters / Setters (used by PluginBootstrap and services)
    // ----------------------------------------------------------------
    public ConfigManager getConfigManager() { return configManager; }
    public void setConfigManager(ConfigManager cm) { this.configManager = cm; }

    public Messages getMessages() { return messages; }
    public void setMessages(Messages m) { this.messages = m; }

    public DatabaseManager getDatabaseManager() { return databaseManager; }
    public void setDatabaseManager(DatabaseManager db) { this.databaseManager = db; }

    public ClanService getClanService() { return clanService; }
    public void setClanService(ClanService cs) { this.clanService = cs; }

    public MemberService getMemberService() { return memberService; }
    public void setMemberService(MemberService ms) { this.memberService = ms; }

    public RankService getRankService() { return rankService; }
    public void setRankService(RankService rs) { this.rankService = rs; }

    public InviteService getInviteService() { return inviteService; }
    public void setInviteService(InviteService is) { this.inviteService = is; }

    public HomeService getHomeService() { return homeService; }
    public void setHomeService(HomeService hs) { this.homeService = hs; }

    public MenuManager getMenuManager() { return menuManager; }
    public void setMenuManager(MenuManager mm) { this.menuManager = mm; }

    public HookManager getHookManager() { return hookManager; }
    public void setHookManager(HookManager hm) { this.hookManager = hm; }

    public dev.zm.clan.listeners.ClanChatListener getClanChatListener() { return clanChatListener; }
    public void setClanChatListener(dev.zm.clan.listeners.ClanChatListener ccl) { this.clanChatListener = ccl; }
}
