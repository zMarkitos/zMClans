package dev.zm.clan.member.model;

import java.time.Instant;
import java.util.UUID;

/**
 * Represents a single clan member's persistent data.
 * One entry per player-in-clan relationship.
 */
public final class ClanMember {

    private final UUID playerUUID;
    private final UUID clanId;
    private String rankId;
    private final Instant joinedAt;
    private boolean chatEnabled; // whether /clan chat is toggled on

    // Transient — not persisted, set at runtime
    private boolean online;

    public ClanMember(UUID playerUUID, UUID clanId, String rankId, Instant joinedAt) {
        this.playerUUID  = playerUUID;
        this.clanId      = clanId;
        this.rankId      = rankId;
        this.joinedAt    = joinedAt;
        this.chatEnabled = false;
        this.online      = false;
    }

    public UUID getPlayerUUID() { return playerUUID; }
    public UUID getPlayerUuid() { return playerUUID; }
    public UUID getClanId()     { return clanId; }
    public String getRankId()   { return rankId; }
    public String getRank()     { return rankId; }
    public Instant getJoinedAt(){ return joinedAt; }
    public boolean isChatEnabled() { return chatEnabled; }
    public boolean isOnline()   { return online; }

    public void setRankId(String rankId)         { this.rankId = rankId; }
    public void setChatEnabled(boolean enabled)  { this.chatEnabled = enabled; }
    public void setOnline(boolean online)        { this.online = online; }
}
