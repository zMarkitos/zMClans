package dev.zm.clan.task;

import dev.zm.clan.zMClans;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Periodically purges expired clan invitations from memory.
 */
public final class InviteExpireTask extends BukkitRunnable {

    private final zMClans plugin;

    public InviteExpireTask(zMClans plugin) {
        this.plugin = plugin;
    }

    public void start() {
        // Run every 20 seconds
        runTaskTimer(plugin, 400L, 400L);
    }

    @Override
    public void run() {
        plugin.getInviteService().purgeExpired();
    }
}
