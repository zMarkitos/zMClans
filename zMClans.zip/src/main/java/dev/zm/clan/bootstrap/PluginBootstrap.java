package dev.zm.clan.bootstrap;

import dev.zm.clan.command.AdminCommand;
import dev.zm.clan.command.ClanCommand;
import dev.zm.clan.config.ConfigManager;
import dev.zm.clan.config.Messages;
import dev.zm.clan.hook.HookManager;
import dev.zm.clan.listeners.ClanChatListener;
import dev.zm.clan.listeners.FriendlyFireListener;
import dev.zm.clan.listeners.MenuListener;
import dev.zm.clan.listeners.PlayerConnectionListener;
import dev.zm.clan.menu.MenuManager;
import dev.zm.clan.service.ClanService;
import dev.zm.clan.service.HomeService;
import dev.zm.clan.service.InviteService;
import dev.zm.clan.service.MemberService;
import dev.zm.clan.service.RankService;
import dev.zm.clan.storage.DatabaseManager;
import dev.zm.clan.task.AutoSaveTask;
import dev.zm.clan.task.InviteExpireTask;
import dev.zm.clan.zMClans;
import org.bukkit.Bukkit;

import java.util.Objects;

/**
 * Orchestrates the ordered startup of all plugin components.
 * Order matters: Config → DB → Services → Commands → Listeners → Tasks.
 */
public final class PluginBootstrap {

    private final zMClans plugin;

    public PluginBootstrap(zMClans plugin) {
        this.plugin = plugin;
    }

    public void boot() {
        printBanner();

        // 1. Configuration & language
        ConfigManager config = new ConfigManager(plugin);
        config.load();
        plugin.setConfigManager(config);

        Messages messages = new Messages(plugin);
        messages.load();
        plugin.setMessages(messages);

        // 2. Database
        DatabaseManager db = new DatabaseManager(plugin);
        if (!db.connect()) {
            plugin.getLogger().severe("Could not connect to database! Disabling plugin.");
            Bukkit.getPluginManager().disablePlugin(plugin);
            return;
        }
        db.runMigrations();
        plugin.setDatabaseManager(db);

        // 3. Services
        RankService rankService = new RankService(plugin);
        rankService.load();
        plugin.setRankService(rankService);

        ClanService clanService = new ClanService(plugin);
        plugin.setClanService(clanService);

        MemberService memberService = new MemberService(plugin);
        plugin.setMemberService(memberService);
        memberService.loadAll();

        InviteService inviteService = new InviteService(plugin);
        plugin.setInviteService(inviteService);

        HomeService homeService = new HomeService(plugin);
        plugin.setHomeService(homeService);

        // 4. Menu system
        MenuManager menuManager = new MenuManager(plugin);
        menuManager.loadAll();
        plugin.setMenuManager(menuManager);

        // 5. Hooks (Vault, PlaceholderAPI)
        HookManager hookManager = new HookManager(plugin);
        hookManager.registerAll();
        plugin.setHookManager(hookManager);

        // 6. Commands (single instance per command — reused for executor + tabcompleter)
        ClanCommand clanCommand = new ClanCommand(plugin);
        Objects.requireNonNull(plugin.getCommand("clan")).setExecutor(clanCommand);
        Objects.requireNonNull(plugin.getCommand("clan")).setTabCompleter(clanCommand);
        AdminCommand adminCommand = new AdminCommand(plugin);
        Objects.requireNonNull(plugin.getCommand("zmclan")).setExecutor(adminCommand);
        Objects.requireNonNull(plugin.getCommand("zmclan")).setTabCompleter(adminCommand);

        // 7. Event listeners
        var pm = Bukkit.getPluginManager();
        pm.registerEvents(new PlayerConnectionListener(plugin), plugin);
        ClanChatListener chatListener = new ClanChatListener(plugin);
        plugin.setClanChatListener(chatListener);
        pm.registerEvents(chatListener, plugin);
        pm.registerEvents(new FriendlyFireListener(plugin), plugin);
        pm.registerEvents(new MenuListener(plugin), plugin);

        // 8. Async tasks
        new AutoSaveTask(plugin).start();
        new InviteExpireTask(plugin).start();

        plugin.getLogger().info("zMClans v" + plugin.getDescription().getVersion() + " enabled!");
    }

    private void printBanner() {
        plugin.getLogger().info("  ______ _       _");
        plugin.getLogger().info(" |___  /| |     | |");
        plugin.getLogger().info("    / / | |\\/| | | |_ __");
        plugin.getLogger().info("   / /  | |  | | | | '_ \\");
        plugin.getLogger().info("  / /___| |  | | | | | | |");
        plugin.getLogger().info(" /_____|_|  |_|_|_|_| |_| Clans");
        plugin.getLogger().info(" By zM_Dev | v" + plugin.getDescription().getVersion());
    }
}
