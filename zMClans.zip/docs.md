# Documentación Oficial - zMClans

Plugin de clanes moderno, de alto rendimiento y totalmente configurable para servidores **Paper / Purpur 1.20+** (Java 21).

---

## 1. Requisitos e Instalación

### Requisitos del Sistema
- **Servidor:** Paper, Purpur o forks compatibles con la API 1.20+ (soporta 1.20, 1.20.6, 1.21+).
- **Java:** Java 21 o superior.
- **Dependencias Opcionales (Soft-dependencies):**
  - **Vault:** Para cobro por creación de clan mediante plugin de economía (EssentialsX, EconomyEngine, etc.).
  - **PlaceholderAPI:** Para uso de variables en chat, scoreboards y tablists.

### Instalación
1. Descarga el archivo compilado `zMClans-1.0.0.jar` desde `target/`.
2. Coloca el archivo en la carpeta `plugins/` de tu servidor.
3. Inicia o reinicia el servidor para generar los archivos de configuración por defecto (`plugins/zMClans/`).
4. Configura `config.yml`, `ranks.yml` y los archivos en `guis/` y `langs/` según tus necesidades.
5. Ejecuta `/zmclan reload` para aplicar los cambios sin reiniciar.

---

## 2. Funcionalidades Implementadas

- **Gestión Completa de Clanes:** Creación, invitaciones, aceptación, rechazo, salida voluntaria, expulsión de miembros y disolución de clan.
- **Sistema de Rangos Jerárquico:** Múltiples rangos personalizables con prioridades y permisos individuales (`ranks.yml`).
- **Hogar de Clan (`/clan home` / `/clan sethome`):**
  - Calentamiento configurable (*warmup*) con detección de movimiento en tiempo real para cancelación inmediata (ignora rotaciones de cámara).
  - Tiempo de reutilización (*cooldown*) configurable con permiso de bypass.
  - Verificación estricta de mundos cargados y permisos de rango (`SET_HOME`, `USE_HOME`).
- **Chat Privado de Clan:**
  - Integrado nativamente con la API moderna de Paper (`AsyncChatEvent`) para evitar advertencias de deprecación.
  - Modo alternable (`/clan chat`) o envío directo (`/clan chat <mensaje>`).
- **Fuego Amigo (Friendly Fire):**
  - Protección de daño cuerpo a cuerpo y proyectiles (flechas, tridentes, etc.) entre miembros del mismo clan.
  - Alternable dinámicamente mediante comando o menú de configuración.
- **Sistema de Invitaciones Asíncrono:**
  - Caducidad automática de invitaciones en hilo independiente sin bloqueos.
  - Eliminación segura contra concurrencia (`ConcurrentModificationException`).
- **Sistema de Puntos y Clasificación:**
  - Sistema de puntos para clanes gestionable por administradores (`/zmclan points`).
  - Menú interactivo y paginado de leaderboard/lista de clanes.
- **Modificación de Tag y Colores (`/clan modtag <tag>`):**
  - Soporta Adventure MiniMessage con gradientes y decoraciones seguras: `<b><gradient:#9A23FF:#7C09DE:#9A23FF>ZEPHY</gradient></b>`.
  - Soporta códigos hexadecimales y legacy: `&#9A23FF&lZ&#8B16EF&lE&#7C09DE&lP&#8B16EF&lH&#9A23FF&lY`.
  - **Seguridad Garantizada:** Bloquea cualquier inyección de eventos (`click`, `hover`, comandos, etc.) permitiendo exclusivamente colores y estilos visuales. La validación de longitud (mín/máx) y caracteres alfanuméricos se evalúa de forma estricta sobre el texto visible desprovisto de formato.
- **Menús Gráficos (GUIs) Desacoplados:**
  - Arquitectura orientada a datos (YAML) que permite personalizar interfaz y estética sin modificar código Java.

---

## 3. Comandos y Permisos

### Comandos de Jugador (`/clan`, alias: `/c`, `/clans`)

| Comando | Descripción | Permiso Bukkit | Permiso de Rango |
| :--- | :--- | :--- | :--- |
| `/clan` | Abre el menú interactivo principal | Ninguno | Ninguno |
| `/clan create <nombre> [tag/modtag]` | Crea un nuevo clan (el tag/modtag es opcional) | `zmclans.clan.create` | N/A |
| `/clan info [clan]` | Muestra detalles del clan | Ninguno | Ninguno |
| `/clan list` | Abre el menú del leaderboard | Ninguno | Ninguno |
| `/clan invite <jugador>` | Invita a un jugador al clan | `zmclans.clan.invite` | `INVITE` |
| `/clan invites` | Abre la GUI de invitaciones recibidas | Ninguno | Ninguno |
| `/clan accept [clan]` | Acepta una invitación pendiente | Ninguno | Ninguno |
| `/clan deny [clan]` | Rechaza una invitación pendiente | Ninguno | Ninguno |
| `/clan members` | Abre la GUI de miembros | Ninguno | Ninguno |
| `/clan setrank <jugador> <rango>` | Asigna un rango a un miembro | Ninguno | `PROMOTE` |
| `/clan kick <jugador>` | Expulsa a un miembro | `zmclans.clan.kick` | `KICK` |
| `/clan leave` | Abandona el clan actual | Ninguno | N/A (no líder) |
| `/clan disband [confirm]` | Disuelve permanentemente el clan | `zmclans.clan.disband` | `DISBAND` |
| `/clan home` | Teletransporta al hogar del clan | `zmclans.clan.home` | `USE_HOME` |
| `/clan sethome` | Establece el hogar en la posición actual | `zmclans.clan.sethome` | `SET_HOME` |
| `/clan chat [mensaje]` | Alterna o envía chat de clan | `zmclans.clan.chat` | `USE_CHAT` |
| `/clan ff` | Alterna el fuego amigo | Ninguno | `EDIT_SETTINGS` |
| `/clan desc <texto>` | Cambia la descripción del clan | Ninguno | `EDIT_DESCRIPTION` |
| `/clan modtag <tag>` | Cambia el tag y colores del clan (Gradients / Hex) | `zmclans.clan.modtag` | `MODTAG` |
| `/clan settings` | Abre la GUI de configuración del clan | Ninguno | `EDIT_SETTINGS` |
| `/clan stats` | Abre la GUI de estadísticas del clan | Ninguno | Ninguno |
| `/clan help` | Muestra la ayuda de comandos | Ninguno | Ninguno |

### Permisos Especiales de Jugador
- `zmclans.clan.bypass.cooldown`: Omite el cooldown de teletransporte a home.
- `zmclans.clan.bypass.cost`: Omite el costo económico de creación de clan.

### Comandos de Administrador (`/zmclan`, alias: `/zmclans`, `/clanadmin`)
*Requiere el permiso: `zmclans.admin`*

| Comando | Descripción |
| :--- | :--- |
| `/zmclan help` | Muestra la lista de comandos de administración |
| `/zmclan reload` | Recarga configuraciones, idiomas, rangos y menús |
| `/zmclan info <clan>` | Muestra información administrativa del clan |
| `/zmclan disband <clan>` | Disuelve un clan forzosamente |
| `/zmclan setleader <clan> <jugador>` | Transfiere el liderazgo forzosamente a un miembro |
| `/zmclan points <add\|set\|remove> <clan> <cant>` | Modifica los puntos de un clan |

---

## 4. Rangos y Permisos de Clan (`ranks.yml`)

Los rangos se definen en `ranks.yml` con una jerarquía basada en `priority` (mayor número = mayor jerarquía). Un miembro no puede expulsar ni promover a otro jugador con prioridad igual o superior.

### Permisos de Rango Disponibles:
- `USE_HOME`: Permite usar `/clan home`.
- `USE_CHAT`: Permite usar el chat privado del clan.
- `INVITE`: Permite invitar a nuevos jugadores.
- `KICK`: Permite expulsar miembros de rango inferior.
- `PROMOTE`: Permite cambiar el rango de miembros de rango inferior.
- `SET_HOME`: Permite cambiar la ubicación del hogar del clan.
- `EDIT_DESCRIPTION`: Permite actualizar la descripción.
- `EDIT_SETTINGS`: Permite alternar fuego amigo e invitaciones abiertas.
- `TRANSFER_LEADER`: Permite traspasar la propiedad del clan.
- `DISBAND`: Permite disolver el clan.
- `MODTAG`: Permite modificar el tag y formato de colores del clan.

### Rangos por Defecto:
1. `recruit` (Prioridad 1): Permisos básicos (`USE_HOME`, `USE_CHAT`).
2. `member` (Prioridad 2): Miembro regular.
3. `officer` (Prioridad 3): Acceso a `INVITE`.
4. `admin` (Prioridad 4): Acceso a `INVITE`, `KICK`, `PROMOTE`, `SET_HOME`, `EDIT_DESCRIPTION`.
5. `leader` (Prioridad 5): Acceso total (`is-leader: true`).

---

## 5. GUIs y Configuración YAML

Los menús se encuentran en la carpeta `guis/` y son compatibles con la convención de DeluxeMenus:

### Archivos de Menús:
- `general.yml`: Menú principal para jugadores sin clan (`no_clan`) y con clan (`clan_home`).
- `members.yml`: Lista interactiva de miembros paginada.
- `member_manage.yml`: Panel de gestión individual de un miembro (promover, degradar, expulsar, transferir liderazgo).
- `clanlist.yml`: Clasificación y exploración de clanes paginada.
- `invite.yml`: Lista paginada de jugadores online listos para invitar con 1 clic.
- `invites.yml`: Lista de invitaciones pendientes recibidas (Click Izquierdo: Aceptar, Click Derecho: Rechazar).
- `settings.yml`: Panel interactivo para alternar fuego amigo, invitaciones y descripción.
- `stats.yml`: Panel detallado con estadísticas y datos del clan.
- `confirm.yml`: Menú genérico de confirmación segura para acciones destructivas o críticas.

### Propiedades Compatibles en Ítems:
- `material`: Nombre del material Bukkit (e.g., `EMERALD`, `BARRIER`, `playerhead`).
- `slot`: Posición numérica individual (0 a 53).
- `slots`: Lista o rango de slots para ítems de relleno (e.g., `[0,1,2,3,4,5]`).
- `display-name` / `display_name`: Nombre visible con soporte para colores hexadecimales (`&#RRGGBB`) y estándar (`&a`).
- `lore`: Lista de líneas de descripción.
- `glow`: `true` / `false` para dar efecto de encantamiento.
- `item-flags` / `item_flags`: Flags Bukkit (e.g., `[HIDE_ATTRIBUTES, HIDE_ENCHANTS]`).
- `action`: Acción a ejecutar al interactuar:
  - `CLOSE`: Cierra el inventario.
  - `CANCEL`: Vuelve al menú principal según el contexto.
  - `PAGE_NEXT` / `PAGE_PREV`: Navegación de páginas en menús paginados.
  - `OPEN_GUI:<nombre>`: Abre otro menú (e.g., `OPEN_GUI:clan_members`).
  - `CREATE_CLAN`: Muestra instrucciones para crear clan.
  - `SHOW_HELP`: Muestra la guía de comandos.
  - `TOGGLE_CHAT`: Alterna el modo de chat de clan.
  - `CLAN_HOME_OR_SETHOME`: Click Izquierdo = Teletransporte, Click Derecho = Set Home.
  - `TOGGLE_SETTING:friendly_fire`: Alterna el estado de fuego amigo.
  - `TOGGLE_SETTING:open_invitations`: Alterna invitaciones abiertas.
  - `MEMBER_PROMOTE`, `MEMBER_DEMOTE`, `MEMBER_KICK`, `MEMBER_TRANSFER_LEADER`: Acciones de gestión de miembros.
  - `CMD_PLAYER:<comando>`: Ejecuta un comando como el jugador.
  - `CMD_CONSOLE:<comando>`: Ejecuta un comando desde la consola.
- `require-rank-permission` / `require_rank_permission`: Oculta el ítem si el miembro no cuenta con el permiso de rango especificado.

---

## 6. Idiomas, Placeholders e Integraciones

### Configuración de Idioma (`config.yml`)
En `config.yml`, la opción `language: "ES"` (o `"EN"`) determina el archivo cargado desde `plugins/zMClans/langs/`:
- `lang_ES.yml`: Español completo.
- `lang_EN.yml`: Inglés completo.
Ambos archivos mantienen sincronía total de claves y admiten formato de color hexadecimal (`&#RRGGBB`).

### Placeholders Integrados
Utilizables en mensajes y GUIs:
- `{player}`: Nombre del jugador.
- `{clan}`: Nombre del clan.
- `{tag}`: Tag del clan.
- `{leader}`: Nombre del líder.
- `{rank}`: Nombre visible del rango.
- `{members}`: Cantidad actual de miembros.
- `{max}`: Límite máximo de miembros del clan.
- `{points}`: Puntos del clan.
- `{created_at}`: Fecha de fundación.
- `{home_location}`: Coordenadas del hogar del clan.
- `{friendly_fire_status}`: Estado del fuego amigo (ON / OFF).
- `{chat_status}`: Estado del chat de clan (ON / OFF).
- `{creation_cost}`: Costo de creación configurado.

### PlaceholderAPI (PAPI) - zMClans & UltimateClans Compatibility

El plugin registra automáticamente las expansiones `%zmclans_...%` y el alias de compatibilidad directa `%uclans_...%`. Ambas admiten exactamente los mismos parámetros.

#### 1. Identificación y Estado
- `%zmclans_hasclan%`: `true` si el jugador pertenece a un clan, `false` en caso contrario.
- `%zmclans_hasclan_formated%`: Retorna el modtag/tag formateado del clan si tiene clan, o cadena vacía si no.
- `%zmclans_hasclan_formated_nocolor%`: Retorna el tag limpio sin colores si tiene clan.
- `%zmclans_clan%` / `%zmclans_name%`: Nombre base/identificador del clan.
- `%zmclans_clanid%`: UUID único del clan.

#### 2. Tags y ModTags
- `%zmclans_modtag%`: **Retorna el tag estilizado con colores y gradientes si existe. Si el clan no configuró un modtag personalizado, muestra automáticamente el nombre del clan.**
- `%zmclans_tag%` / `%zmclans_tag_color%` / `%zmclans_tag_formated%`: Retorna el tag formateado.
- `%zmclans_tag_nocolor%` / `%zmclans_tag_formated_nocolor%`: Tag sin códigos de color.

#### 3. Liderazgo y Miembros
- `%zmclans_leader%`: Nombre del líder del clan.
- `%zmclans_leader_formated%`: Nombre del líder con formato de color.
- `%zmclans_is_leader%`: `true` si el jugador es líder, `false` en caso contrario.
- `%zmclans_members%` / `%zmclans_count_members%`: Cantidad total de miembros.
- `%zmclans_onlinemembers%` / `%zmclans_count_onlinemembers%`: Miembros conectados en el servidor.
- `%zmclans_slots%` / `%zmclans_slots_total%`: Límite máximo de miembros del clan.

#### 4. Puntos y Clasificación (Top)
- `%zmclans_points%`: Puntos formateados con separador de miles (`1,500`).
- `%zmclans_points_unformated%`: Puntos en formato numérico plano (`1500`).
- `%zmclans_current_position%` / `%zmclans_top%`: Posición del clan en el ranking general (e.g. `1`, `2`).
- `%zmclans_top:<N>%`: Nombre del clan en la posición N del ranking (e.g. `%zmclans_top:1%`).
- `%zmclans_top_tag:<N>%`: Tag del clan en la posición N del ranking.
- `%zmclans_top_points:<N>%`: Puntos del clan en la posición N del ranking.
- `%zmclans_top_leader:<N>%`: Líder del clan en la posición N del ranking.
- `%zmclans_top_members:<N>%`: Miembros del clan en la posición N del ranking.

#### 5. Configuración y Estados
- `%zmclans_desc%` / `%zmclans_desc_color%`: Descripción del clan con colores.
- `%zmclans_desc_nocolor%`: Descripción del clan sin colores.
- `%zmclans_is_ff%` / `%zmclans_global_ff%`: `true` si el fuego amigo está activo.
- `%zmclans_is_ff_formated%`: `ON` o `OFF`.
- `%zmclans_isopen%`: `true` si las invitaciones abiertas están activas.
- `%zmclans_isopen_formated%`: `ON` o `OFF`.
- `%zmclans_chat_active%`: `true` si el jugador tiene activo el modo chat de clan.
- `%zmclans_chat_active_formatted%`: `ON` o `OFF`.

#### 6. Hogar (Home) y Fechas
- `%zmclans_hashome%`: `true` si el clan tiene hogar configurado.
- `%zmclans_home%`: Coordenadas legibles (`world (100, 64, -200)`).
- `%zmclans_home_world%`: Nombre del mundo del hogar.
- `%zmclans_home_x%`, `%zmclans_home_y%`, `%zmclans_home_z%`: Coordenadas individuales.
- `%zmclans_creation_date%`: Fecha de fundación en formato `YYYY-MM-DD`.
- `%zmclans_creation_hours%`: Timestamp de creación en época unix.

#### 7. Información del Jugador en el Clan
- `%zmclans_player_role%`: ID del rango del jugador en el clan (`recruit`, `member`, `leader`, etc.).
- `%zmclans_player_role_formated%`: Nombre visible y color del rango.
- `%zmclans_player_role_prefix%`: Prefijo estilizado del rango del jugador.
- `%zmclans_player_joindate%`: Fecha de ingreso del jugador al clan.
- `%zmclans_player_permissions_amount%`: Cantidad de permisos que tiene el rango del jugador.

#### 8. Búsqueda Cruzada
- `%zmclans_search_player_clan:<jugador>%`: Retorna el nombre del clan al que pertenece el jugador consultado.

#### 9. Placeholders Relacionales (`%rel_zmclans_...%` y `%rel_uclans_...%`)
Permite colorear nombres en Tablist o Nametag según la relación entre dos jugadores:
- `%rel_zmclans_relboolean_member%`: `true` si ambos jugadores pertenecen al mismo clan.
- `%rel_zmclans_relboolean_ally%`: `true` si son aliados o del mismo clan.
- `%rel_zmclans_relboolean_rival%`: `true` si son rivales.
- `%rel_zmclans_relcolor%`: Retorna `&a` si son del mismo clan y `&c` si son de clanes diferentes o sin clan.
- `%rel_zmclans_reltext%`: Retorna `Member` si pertenecen al mismo clan.
- `%rel_zmclans_reltext_coloured%`: Retorna `§aMember` formateado.

---

## 7. Almacenamiento: SQLite y MySQL

El plugin incluye soporte nativo para **SQLite** y **MySQL** gestionado con un pool de conexiones **HikariCP**:

```yaml
storage:
  type: "SQLITE" # o "MYSQL"
  auto-save-interval: 5 # Minutos entre guardados periódicos automáticos

  sqlite:
    file: "database/clans.db"

  mysql:
    host: "localhost"
    port: 3306
    database: "zmclans"
    username: "root"
    password: "password"
    pool-size: 10
    useSSL: false
    allowPublicKeyRetrieval: true
```

- **Rendimiento:** Las operaciones de lectura inicial y guardado asíncrono se ejecutan en hilos secundarios para nunca bloquear el hilo principal (*main server thread*).
- **Seguridad en Cierre:** Durante `onDisable()`, el método `saveAllSync()` garantiza que todos los cambios pendientes se escriban en disco de forma síncrona antes de liberar las conexiones.

---

## 8. Pruebas Realizadas y Limitaciones Conocidas

### Pruebas Realizadas
1. **Compilación Maven:** Construcción exitosa con `mvn clean package` bajo Java 21 y Paper 1.20+ (`BUILD SUCCESS`).
2. **Validación de Listeners:** Verificación de compatibilidad con `AsyncChatEvent` de Paper y `PlayerMoveEvent` optimizado.
3. **Mapeo de Inventarios:** Validación de layouts sin solapamiento de slots entre botones interactivos y paneles de relleno.
4. **Sincronización de Idiomas:** Comprobación de paridad de claves entre `lang_ES.yml` y `lang_EN.yml`.

### Limitaciones Conocidas
- El soporte de economía requiere un plugin compatible con el servicio `net.milkbowl.vault.economy.Economy`. Si Vault no está presente o no hay un proveedor de economía, la creación de clanes funcionará como gratuita automáticamente.
- Los banners dinámicos personalizados de clan en los menús utilizan por defecto el escudo o estandarte representativo según la configuración de la GUI.


## Security and lifecycle notes
- Clan leaders cannot leave their own clan; they must transfer leadership or disband it. This is enforced in the member service, not only in the GUI.
- The clan information screen is the consolidated clan overview; the duplicate statistics GUI has been removed. Legacy stats menu aliases route to the information screen.
